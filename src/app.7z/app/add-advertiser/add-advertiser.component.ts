import { Component, OnInit, ViewChild } from '@angular/core';
import {SelectionModel} from '@angular/cdk/collections';
import {MatTableDataSource} from '@angular/material/table';
import { NavigateServiceService } from '../navigate-service.service';
import { AdvertiserDetailsDTO } from '../shared/classes/AdvertiserDetailsDTO';
import { AdvertiserDetails } from '../shared/classes/AdvertiserDetails';
import { HttpClient } from '@angular/common/http';
import { MatPaginator } from '@angular/material';
import { AdvertiserDetailsService } from '../shared/services/advertiser-details.service';

const lengthOfCode = 10;
@Component({
  selector: 'app-add-advertiser',
  templateUrl: './add-advertiser.component.html',
  styleUrls: ['./add-advertiser.component.css']
})
export class AddAdvertiserComponent implements OnInit {
  AdvertiserDetailsDTO:AdvertiserDetailsDTO[];
  displayedColumns: string[] = ['select','AdName', 'AdPhon', 'AdMail', 'Adtext', 'Area', 'Category'];
  dataSource = new MatTableDataSource<AdvertiserDetailsDTO>(this.AdvertiserDetailsDTO);
  selection = new SelectionModel<AdvertiserDetailsDTO>(true, []);
  ArrAdvertiser:AdvertiserDetails[]=[];
  flag:boolean;
  lenghtTable:number;
  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    this.flag=numSelected === numRows;
    return numSelected === numRows;
  } 
  possible:string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,./;'[]\=-)(*&^%$#@!";
 
   makeRandom(lengthOfCode: number, possible: string) {
    let text = "";
   
    for (let i = 0; i < lengthOfCode; i++) {
      text += possible.charAt(Math.floor(Math.random() * possible.length));
    } console.log(text)
      return text;
  }
  
  add(){ 
    this.dataSource.data.forEach(row =>{
      if(this.selection.isSelected(row))
    {
      this.ArrAdvertiser.push(row)
    }} )
    console.log(this.ArrAdvertiser.length)
    // debugger;
    this.ArrAdvertiser.forEach(element => {
      element.Adkod= this.makeRandom(lengthOfCode, this.possible);
      element.AdStatus=1;
      console.log(element.AreaId);
      this.AdvertiserDetailsServise.Put(<AdvertiserDetails>element).subscribe(x=>{
        this.AdvertiserDetailsServise.GetStatus( 0).subscribe(x=>{this.AdvertiserDetailsDTO=<AdvertiserDetailsDTO[]>x;
          this.dataSource = new MatTableDataSource<AdvertiserDetailsDTO>(this.AdvertiserDetailsDTO);
      }); });
    });
  }
  
  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    if(this.isAllSelected())
     {
        this.selection.clear();this.flag=true} else
        {this.dataSource.data.forEach(row => this.selection.select(row));}this.flag=false
        
  }

  /** The label for the checkbox on the passed row */
  checkboxLabel(row?: AdvertiserDetailsDTO): string {
   
    if (!row) {
      return `${this.isAllSelected() ? 'select' : 'deselect'} all`;
    }
    let num:number=<number>this.AdvertiserDetailsDTO.findIndex(x=>x.AdId==row.AdId)

    return `${this.selection.isSelected(row) ? 'deselect' : 'select'} row ${num + 2}`;
  }
  constructor(private service:NavigateServiceService,private http:HttpClient,private AdvertiserDetailsServise:AdvertiserDetailsService) {
    
   }
   @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  ngOnInit() {
    this.AdvertiserDetailsServise.GetStatus( 0).subscribe(x=>{this.AdvertiserDetailsDTO=<AdvertiserDetailsDTO[]>x;
      console.log(this.AdvertiserDetailsDTO)
      this.lenghtTable=this.AdvertiserDetailsDTO.length;
      this.dataSource = new MatTableDataSource<AdvertiserDetailsDTO>(this.AdvertiserDetailsDTO);
      this.selection = new SelectionModel<AdvertiserDetailsDTO>(true, []);
      this.dataSource.paginator = this.paginator;
    })
  }
  // AddAdvertiser(row: AdvertiserDetailsDTO)
  // {

  //     if(this.selection.isSelected(row))
  //     {
  //       console.log(row.AreaId)
  //       this.ArrAdvertiser.push(row);
  //     }
  //     else
  //     {
  //       this.ArrAdvertiser.splice(this.ArrAdvertiser.findIndex(x=>x.AdId==row.AdId),1);
  //     } 
     
  // }
  // AddAdvertiserAll()
  // {
  //   {if(!this.flag)
  //    {  this.ArrAdvertiser=this.AdvertiserDetailsDTO;}
  //    else{
  //     this.ArrAdvertiser=[];
  //    }
  //   } console.log(this.ArrAdvertiser.length)
  // }
  
}
