import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddItemServiesComponent } from './add-item-servies.component';

describe('AddItemServiesComponent', () => {
  let component: AddItemServiesComponent;
  let fixture: ComponentFixture<AddItemServiesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddItemServiesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddItemServiesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
