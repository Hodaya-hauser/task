import { Component, OnInit } from '@angular/core';
import { NavigateServiceService } from '../navigate-service.service';
import { Router } from '@angular/router';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { ItemsServies } from '../shared/classes/ItemsServies';
import { HttpClient } from '@angular/common/http';
import { ItemsServiesService } from '../shared/services/items-servies.service';

@Component({
  selector: 'app-add-item-servies',
  templateUrl: './add-item-servies.component.html',
  styleUrls: ['./add-item-servies.component.css']
})
export class AddItemServiesComponent implements OnInit {

  ItemsServiesDTO1:ItemsServiesDTO[];
  item:ItemsServiesDTO;
  constructor(private service:NavigateServiceService,
    private r:Router,
    private http:HttpClient,
    private ItemsServiesService:ItemsServiesService) {
      ItemsServiesService.GetISByStatus(0).subscribe(res=>{this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;})
  }
  ngOnInit() {
  }
  show(item)
  {
    this.item=item;
  }

  add(item){
    item.status=1;
this.ItemsServiesService.Put(<ItemsServies>item).subscribe(x=>{});
  }

}
