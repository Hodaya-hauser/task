import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { NavigateServiceService } from '../navigate-service.service';
import {FormControl, Validators, FormGroup} from '@angular/forms';
import { AdvertiserDetails } from '../shared/classes/AdvertiserDetails';
import { AdvertiserDetailsService } from '../shared/services/advertiser-details.service';
@Component({
  selector: 'app-advertisement-extant',
  templateUrl: './advertisement-extant.component.html',
  styleUrls: ['./advertisement-extant.component.css']
})
export class AdvertisementExtantComponent implements OnInit {
  adForm: FormGroup;
  email = new FormControl('', [Validators.required, Validators.email]);
  nameer = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  pass = new FormControl('', [Validators.required]);
  advertisment:AdvertiserDetails;
  showErrorMass: boolean=false;
  getErrorMessage() {
    if(this.submitted){
    return this.email.hasError('required') ? 'שדה חובה':
        this.email.hasError('email') ? 'מייל לא חוקי':
            '';}
            else{
             return this.email.hasError('email') ? 'מייל לא חוקי':
             '';
            }
  }
  getErrorMessagename() {
    if(this.submitted){
    return this.nameer.hasError('required') ? 'שדה חובה':
    this.nameer.hasError('maxLenght') ? 'שם לא חוקי':
            '';
  }}
  getErrorMessagepassword() {
    if (this.submitted) {
    return this.pass.hasError('required') ? 'שדה חובה':
            '';}
  }
  hide=true;
  submitted:boolean=false;
  mail: string = "";
  name: string = "";
  password: string = "";
  public show: boolean = false;
  id:number;
  constructor(private http:HttpClient,
    private r:Router,
    private service:NavigateServiceService,
    private AdvertismentDetailsServies:AdvertiserDetailsService,
    private active:ActivatedRoute) { }
    enterToArea(adForm:FormGroup)
    {
        this.submitted = false;
        if (adForm.invalid) 
        {
            this.submitted = true;
        }
        else 
        {
            this.AdvertismentDetailsServies.GetByMailName(this.mail.toString(),this.name.toString()).subscribe(res => 
           {this.advertisment=<AdvertiserDetails>res
        console.log(this.advertisment)    //  &&this.password=="1234"
       if(this.advertisment!=null&& this.advertisment.Adkod==this.password)
       {   
       let log:any
        log={
        user:"advertiser",
        id:this.advertisment.AdId,
        name:this.advertisment.AdName
        }
         localStorage.setItem("user", JSON.stringify(log));
        let a:any =this.active.parent.component; 
        a.prototype.setAd(this.advertisment.AdName);
         this.show = false;
         console.log(this.advertisment.AdId)
         this.service.NextPAgeWithParam("advertisement-area",this.advertisment.AdId);
       }
       else 
       {
         this.show = true;
       }
      });
  }

  // --------------------------------------------
    // this.getErrorMessagename();
    // this.submitted = false;
    //   if(!form.invalid){
    //   this.submitted = true;
}
  ngOnInit() {
    this.adForm = new FormGroup({
      pass : new FormControl('', [Validators.required]),
      email : new FormControl('', [Validators.required, Validators.email]),
      nameer : new FormControl('', [Validators.required, Validators.maxLength(50)])
    });
    
  }
  forget_password(){
    this.service.NextPAge("forget-password");

    }
  adverismentarea(){
     {
      //  
      if (this.nameer.invalid||this.email.invalid||this.pass.invalid) {
        this.submitted=true;
        this.showErrorMass=true;
        this.show=false;
       
      }  else{
        this.showErrorMass=false;
        console.log(this.password)
       this.AdvertismentDetailsServies.GetByMailName(this.mail.toString(),this.name.toString()).subscribe(res => 
      {this.advertisment=<AdvertiserDetails>res
        console.log(this.advertisment)    //  &&this.password=="1234"
       if(this.advertisment!=null&& this.advertisment.Adkod==this.password)
       {   
       let log:any
        log={
        user:"advertiser",
        id:this.advertisment.AdId,
        name:this.advertisment.AdName
        }
         localStorage.setItem("user", JSON.stringify(log));
        let a:any =this.active.parent.component; 
        a.prototype.setAd(this.advertisment.AdName);
         this.show = false;
         console.log(this.advertisment.AdId)
         this.service.NextPAgeWithParam("advertisement-area",this.advertisment.AdId);
       }
       else 
       {
         this.show = true;
       }
      });
     }
    }
  }
}