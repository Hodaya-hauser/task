import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NavigateServiceService } from '../navigate-service.service';
import { AdvertiserDetails } from '../shared/classes/AdvertiserDetails';
import { Areas } from '../shared/classes/Areas';
import { FormsModule, FormGroup, FormGroupDirective } from '@angular/forms';
import { CommonCategories } from '../shared/classes/CommonCategories';
import { FormControl, Validators } from '@angular/forms';
import { AdvertiserDetailsService } from '../shared/services/advertiser-details.service';
import { AreasService } from '../shared/services/areas.service';
import { CategoriesService } from '../shared/services/categories.service';
import { resolve } from 'url';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-advertisement',
  templateUrl: './advertisement.component.html',
  styleUrls: ['./advertisement.component.css']

})
export class AdvertisementComponent implements OnInit {
  adForm: FormGroup;
  email = new FormControl('', [Validators.required, Validators.email]);
  nameer = new FormControl('', [Validators.required, Validators.maxLength(50)]);
  tel = new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')]);
  areaf = new FormControl('', [Validators.required]);
  categor = new FormControl('', [Validators.required]);
  text = new FormControl('', [Validators.required]);
  loading: boolean;

  ngOnInit() {
    this.adForm = new FormGroup({
      email : new FormControl('', [Validators.required, Validators.email]),
      nameer : new FormControl('', [Validators.required, Validators.maxLength(50)]),
      tel : new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')]),
      areaf : new FormControl('', [Validators.required]),
      categor : new FormControl('', [Validators.required]),
      text : new FormControl('', [Validators.required])
    });
  }
  getErrorMessageemail() {

    if (this.submitted) {
      return this.email.hasError('required') ? 'שדה חובה':
        this.email.hasError('email') ? 'מייל לא חוקי':
          '';
    }
    else {
      return this.email.hasError('email') ? 'מייל לא חוקי':
        '';
    }
  }
  getErrorMessagename() {
    if (this.submitted) {
      return this.nameer.hasError('required') ? 'שדה חובה':
        this.nameer.hasError('maxLenght') ?  'שם לא חוקי':
          '';
    }

  }
  getErrorMessagetel() {
    return this.tel.hasError('required') ?  'שדה חובה':
      this.tel.hasError('pattern') ? 'מס הטל לא חוקי' :
        '';
  }
  getErrorMessageareaf() {
    if (this.flagArea == false) { return 'איזור לא קיים'
    }
    return this.areaf.hasError('required') ? 'שדה חובה':
      '';
  }
  getErrorMessagecategor() {
    return this.categor.hasError('required') ?  'שדה חובה':
      '';
  }
  getErrorMessagetext() {
    return this.text.hasError('required') ? 'שדה חובה':
      '';
  }
  hide = true;
  areas1: Areas[];
  category1: CommonCategories[];
  flagCategory: boolean = true;
  flagArea: boolean = true;
  submitted: boolean = false;
  ad: AdvertiserDetails = { AreaId: 0, AdCategory: 0, AdMail: "", AdName: "", AdPhon: "", Adtext: "", AdId: 0, Adkod: "", AdStatus: 0 };
  are: any = '';
  catag: any = '';
  constructor(private http: HttpClient,
    private messageService:MessageService, private r: Router, private service: NavigateServiceService,private AdvertismentDetailsServies:AdvertiserDetailsService,private AreaService:AreasService,private CategoriesService:CategoriesService) {
    this.loading=true;
    this.CategoriesService.Get().subscribe(res => {
      this.category1 = <CommonCategories[]>res; console.log(this.category1);
    new Promise((resolve,reject)=>{
        this.AreaService.Get().toPromise().then(res => {
this.loading=false;
      this.areas1 = <Areas[]>res;
    });
    })
  
});

  }
  addAadvertiser(formDirective: FormGroupDirective) {
this.onCatergryChange();
this.onAreaChange();
    this.submitted = false;
    if (this.adForm.invalid||!this.flagArea|| !this.flagCategory||!formDirective) {
      this.submitted = true;
    }
    else {
      // alert("else");
      //לבדוק את ה \ הראשון
      this.AdvertismentDetailsServies.Post(this.ad).subscribe(x => { 
        this.messageService.add({severity:'info', summary:'פניתך הועברה למנהל ניצור איתך קשר בהקדם ', detail:''});
        this.are='';
        this.catag='';
        formDirective.resetForm();
        this.adForm.reset()
      this.ad = { AreaId: 0, AdCategory: 0, AdMail: "", AdName: "", AdPhon: "", Adtext: "", AdId: 0, Adkod: "", AdStatus: 0 };
    });
    }
  }
  advertisementextant() {
    this.service.NextPAge("advertisement-extant");
  }


  onCatergryChange() {
    this.flagCategory = true;
    this.ad.AdCategory = this.getSelectedProductByName(this.catag);
    if (this.ad.AdCategory == 0 && this.catag != null && this.catag != "") { this.flagCategory = false; }
  }

  getSelectedProductByName(categoryName: string): number {
    if (this.category1.find(category => category.CategoryName === categoryName) != null)
      return this.category1.find(category => category.CategoryName === categoryName).CategoryId;
    return 0;
  }
  onAreaChange() {
    this.flagArea = true;
    this.ad.AreaId = this.getSelectedAreaByName(this.are);
    if (this.ad.AreaId == 0 && this.are != null && this.are != "") { this.flagArea = false; }
  }

  getSelectedAreaByName(name: string): number {
    if (this.areas1.find(area => area.name === name) != null)
      return this.areas1.find(area => area.name === name).Id;
    return 0;
  }

}
