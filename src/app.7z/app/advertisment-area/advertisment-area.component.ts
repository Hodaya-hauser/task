import { Component, OnInit, ElementRef, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { CommonCategories } from '../shared/classes/CommonCategories';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { ItemsServies } from '../shared/classes/ItemsServies';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import{HttpHeaders}from '@angular/common/http'
import { Areas } from '../shared/classes/Areas';
import { NavigateServiceService } from '../navigate-service.service';
import { DomSanitizer } from '@angular/platform-browser';
import { Validators, FormControl, FormGroup, NgForm, FormGroupDirective } from '@angular/forms';
import { AdvertiserDetailsService } from '../shared/services/advertiser-details.service';
import { AreasService } from '../shared/services/areas.service';
import { CategoriesService } from '../shared/services/categories.service';
import { ItemsServiesService } from '../shared/services/items-servies.service';


@Component({
  selector: 'app-advertisment-area',
  templateUrl: './advertisment-area.component.html',
  styleUrls: ['./advertisment-area.component.css']
})

export class AdvertismentAreaComponent implements OnInit {
  @ViewChild('image',{static:true}) image: ElementRef;
  addIS:FormGroup;
  nameer = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  kupon = new FormControl('', [Validators.required,Validators.maxLength(10)]);
  areaf = new FormControl('', [Validators.required]);
  categor = new FormControl('', [Validators.required]);
  discountt = new FormControl('', [Validators.required]);
  details = new FormControl('', [Validators.required]);
  hiddenimage = new FormControl('',[Validators.required]);
  IsDealHidden = new FormControl('',[Validators.required]);
  loading_carousel: boolean=false;
  loading_form: boolean=false;
  loading:boolean=true;
  editflag:boolean=false;
   submitted:boolean=false;
  url:any='';
  selectedArea:any='';
  selectedCategory:any='';
  areas1:Areas[];
  selectArea:string[]=[];
  selectCategor:string[]=["qwqert"];
  selectIsDeal:string[]=[];
  category1:CommonCategories[];
  id:number;
  ItemsServies1:ItemsServies[]=[new ItemsServies()];
  ItemsServiesDTO1:ItemsServiesDTO[];
  myFiles: string[] = [];  
  remark:any = '1111111';  
  sMsg: string = ''; 
  ISId:number;
  frmData :FormData;
  ad:string;
  flagImage:boolean[]=[true];
  flagArea:boolean[]=[true];
  flagCategory:boolean[]=[true];
  addItemsServies:ItemsServies={AdId:0,AreaId:0,CategorId:0,ISId:0,ISName:"",CouponId:"",IsDealId:undefined,discount:"",Image:" ",Status:0,CountBuyer:0,CountWatch:0,ISdetails:""};
  flagImagelenght: boolean;
  flagImagetext: boolean;
  imageedit:boolean=false;
  formDirective: FormGroupDirective;
  getErrorMessageisdeal(){
    if (this.addItemsServies.IsDealId==undefined) {
      return this.IsDealHidden.hasError('required') ?'שדה חובה': 
      '';
    }
    return; 
  }
  
  getErrorMessagename() {
    return this.nameer.hasError('required') ?'שדה חובה': 
this.nameer.hasError('maxLenght') ? 'שם לא חוקי':
      '';
}
getErrorMessageimage() {
            '';
   if(this.addItemsServies.Image==" "){
     
          return this.hiddenimage.hasError('required') ?'שדה חובה':
          '';
   }
 

  }
  getErrorMessagekupon() {
    if(this.submitted){
          return this.kupon.hasError('required') ? 'שדה חובה':
    this.kupon.hasError('maxLenght') ?'קוד קופון לא חוקי':
            '';
    }

  }
  getErrorMessageareaf() {
  
 
    return this.areaf.hasError('required') ?'שדה חובה':
              '';
  }
  getErrorMessagecategor() {
    return this.categor.hasError('required') ? 'שדה חובה': 
              '';
  }
  getErrorMessagediscuntt() {
    return this.discountt.hasError('required') ? 'שדה חובה':
      '';
}
getErrorMessagedetails() {
  return this.details.hasError('required') ? 'שדה חובה':
    '';
}
  ngOnInit() { 
    this.flagImagetext=true; 
    this.addIS=new FormGroup({
    nameer : new FormControl('', [Validators.required,Validators.maxLength(50)]),
    kupon :new FormControl('', [Validators.required,Validators.maxLength(10)]),
    areaf : new FormControl('', [Validators.required]),
    categor : new FormControl('', [Validators.required]),
    discountt : new FormControl('', [Validators.required]),
    details : new FormControl('', [Validators.required]),
    hiddenimage : new FormControl('',[Validators.required,Validators.maxLength(50)]),
    IsDealHidden : new FormControl('',[Validators.required])
    });
    this.flagImagelenght=true;
    this.flagImagetext=true;
    this.editflag=false;
    this.id=JSON.parse(localStorage.getItem("user")).id;
   this.ItemsServiesService.GetByAdDTO(this.id).subscribe
   (res=>{this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
    this.ItemsServies1=<ItemsServies[]>res;
       this.AreaService.Get().subscribe
     (res=>{this.areas1=<Areas[]>res;
      new Promise((resolve,reject)=>{this.CategoriesService.Get().toPromise().then
       (res=>{
         this.loading=false;
         this.category1=<CommonCategories[]>res; 
            if(this.ItemsServiesDTO1[0]!=null)
            {
            this.selectArea[0]=this.ItemsServiesDTO1[0].Area
            this.selectCategor[0]=this.ItemsServiesDTO1[0].Categor;
            this.selectIsDeal[0]=this.ItemsServiesDTO1[0].IsDeal;
            }
              for (let index = 1; index < this.ItemsServiesDTO1.length; index++) 
              {
                this.selectArea.push(this.ItemsServiesDTO1[index].Area);
                this.selectCategor.push(this.ItemsServiesDTO1[index].Categor);
                this.selectIsDeal.push(this.ItemsServiesDTO1[index].IsDeal);
              } 
    });})
      });
    }); 
   }
  constructor(private sanitizer:DomSanitizer,
    private service:NavigateServiceService,
    private AreaService:AreasService,
     private CategoriesService:CategoriesService,
     private ItemsServiesService:ItemsServiesService) 
  {
  }
onAreaChanged(area:string,ind:number)
{
  if(ind==-1)
  {
    this.flagArea[0]=true;
    if(this.areas1.find(data => data.name === area)==null&& area!=null && area!="")
    {
      this.flagArea[0]=false
      return 0;
    }
    this.addItemsServies.AreaId=this.areas1.find(data => data.name === area).Id;
  }
}
onCategoryChanged(category:string,ind:number)
{
  if(ind==-1)
  {
    this.flagCategory[0]=true
    if(this.category1.find(data => data.CategoryName === category)==null&& category!=null && category!="")
    {
      this.flagCategory[0]=false
      return 0;
    }console.log(category)
    this.addItemsServies.CategorId=this.category1.find(data => data.CategoryName === category).CategoryId;
  }
}
statistics(){
    if(this.id)
    this.service.NextPAge("stat");
  }
addISToAdvertiser(formDirective: FormGroupDirective)
{
  if (this.selectedArea!='') 
  {
    this.onAreaChanged(this.selectedArea,-1);
  }
  if(this.selectedCategory!='')
  {
    this.onCategoryChanged(this.selectedCategory,-1)
  }
  if(!formDirective||this.addIS.invalid || !this.flagArea[0] ||!this.flagCategory[0]|| this.addItemsServies.Image==" " ||this.addItemsServies.IsDealId==undefined||!this.flagImagelenght||!this.flagImage[0]) 
  {
    this.submitted = true;
  }
  else
  {
    this.loading_carousel=true;
    this.addItemsServies.AdId=this.id;
    this.addItemsServies.Status=0;
    this.frmData=this.uploadFiles();
    this.submitted=false;
    
    if(this.editflag==true)
      {
        this.update(this.addItemsServies);
      }
    else
      {
        this.ItemsServiesService.Post(this.addItemsServies).subscribe
        (
          res=>
          {
            
            this.ISId=<number><unknown>res;
            this.ItemsServiesService.UploadFiles1(this.ISId,this.frmData).subscribe
            (  
              data => 
              {   
                this.sMsg = data as unknown as string;    
                new Promise((resolve,reject)=>{
                  this.ItemsServiesService.GetByAdDTO(this.id).toPromise().then(res=>{
                  this.loading_carousel=false;
                
                  this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
                  this.ItemsServies1=<ItemsServies[]>res;
                }) 
              } 
            ); 
          }
        );})
      }
      this.addItemsServies={AdId:0,AreaId:0,CategorId:0,ISId:0,ISName:"",CouponId:"",IsDealId:undefined,discount:"",Image:" ",Status:0,CountBuyer:0,CountWatch:0,ISdetails:""}
      this.selectedArea='';
      this.submitted=false;
      formDirective.resetForm()
    this.addIS.reset();
      if( this.image.nativeElement.value != null)
      {
        this.image.nativeElement.value = null;
      }
      this.url=undefined;
      this.selectedCategory='';
  }
}
update(item:ItemsServies){
 new Promise(
        (resolve,reject)=>{
  this.ItemsServiesService.Put( item).toPromise().then(x=>{
    if(this.imageedit==true)
    {
      // new Promise(
      //   (resolve,reject)=>{
    this.ItemsServiesService.UploadFiles1(item.ISId,this.frmData).subscribe(  
      data => {   
        this.sMsg = data as unknown as string;
         }  
    ); 
  // } 
  //   );
  }
 this.ItemsServiesService.GetByAdDTO(this.id).subscribe(
  res=>{   
  this.ItemsServiesDTO1=<ItemsServiesDTO[]>res; 
  this.ItemsServies1=<ItemsServies[]>res; 
   this.loading_carousel=false;
   }
 )
          
        
        });
        } 
          );
this.editflag=false;
}
remove(id:number)
{
  this.loading_carousel=true;
  this.ItemsServiesService.Delete(id).subscribe
  (
    x=>
    {
      new Promise((resolve,reject)=>{
      this.ItemsServiesService.GetByAdDTO(this.id).toPromise().then
      (
        res=>
        {
          this.loading_carousel=false;
          this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
          this.ItemsServies1=<ItemsServies[]>res;
         }
       );})
     }
  );
}
edit(item:ItemsServiesDTO)
{  this.imageedit=false
  this.loading_form=true;
  this.editflag=true;
  this.flagImagelenght=true;
  this.flagImagetext=true;
  new Promise((resolve,reject)=>{ this.ItemsServiesService.GetByAdDTO(this.id).toPromise().then(res=>{
    this.loading_form=false;
    this.ItemsServies1=<ItemsServies[]>res;  
    this.addItemsServies=this.ItemsServies1.find(IS=>IS.ISId===item.ISId);
    this.url='data:image/jpg;base64,'+item.ImageUrl;
    if(this.addItemsServies.IsDealId==2)
      {
        this.addItemsServies.IsDealId=1;
      }
    this.selectedCategory=item.Categor;
    this.selectedArea=item.Area;
     })})
}
raise(item:ItemsServies)
{this.loading_carousel=true;
 item.AdId=this.id
  // this.frmData=this.uploadFiles();
  item.Status=2;
  this.ItemsServiesService.Put( item).subscribe(x=>{
    // this.ItemsServiesService.UploadFiles1(id,this.frmData).subscribe(  
    //   data => {   
        // this.sMsg = data as unknown as string; 
        
         this.ItemsServiesService.GetByAdDTO(this.id).subscribe(res=>{  
           this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;this.ItemsServies1=<ItemsServies[]>res;
         
          this.loading_carousel=false;})
    //       }  
    // );
  });
}
getFileDetails(e,ind:number) 
{this.imageedit=true;
  this.myFiles=[]
  this.url="";
  this.flagImagelenght=true;
  this.flagImagetext=true;
  this.flagImage[ind + 1]=true;
  if (e.target.files && e.target.files[0]) 
  {
    if (!e.target.files[0].name.match(/.(jpg|jpeg|png|gif)$/i))
    {this.flagImage[ind + 1]=false;
      if (ind==-1)
      {
        this.addItemsServies.Image=e.target.files[0].name;
      }
    }
    else
    {
      if (ind==-1)
      {
        console.log(e.target.files[0].name)
        this.addItemsServies.Image=e.target.files[0].name;
      }
      if(this.addItemsServies.Image.length>31)
     {
       this.flagImagelenght=false;
     }
     else{
      this.flagImage[ind + 1]=true;
      var reader = new FileReader();
      reader.readAsDataURL(e.target.files[0]); 
      reader.onload = (e) => 
      { 
         if (ind==-1)
        {
          this.url = (<FileReader>event.target).result;
        }
      }
    } 
    }
  }
  else{
    this.addItemsServies.Image=undefined;
    this.flagImagetext=false;
  }
  for (var i = 0; i < e.target.files.length; i++) 
  {  
    this.myFiles.push(e.target.files[i]);  
  } 
  } 
 changeArea(ind:number){
        this.selectArea[ind]=""
      }   
 uploadFiles()
 {  
   const frmData = new FormData();      
   for (var i = 0; i < this.myFiles.length; i++)
    {
      frmData.append("fileUpload", this.myFiles[i]);
      if (i == 0) 
      {  
       frmData.append("remark", this.remark);  
      }  
    }
    let headers = new HttpHeaders
    ({
     'Content-Type': 'application/json'
    });  
   return frmData;
  }
  removeFromPublic(item:ItemsServies)
  {
    item.Status=0;
    if(item.IsDealId==2)
    item.IsDealId=1;
    this.loading_carousel=true;
    this.ItemsServiesService.Put( item).subscribe(x=>{
      this.loading_carousel=false
    });

  } 
  sendtoimg()
  {
    const fileUpload = document.getElementById('file') as HTMLInputElement;
    fileUpload.click()
  }
}