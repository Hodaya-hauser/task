import { Component, OnInit, Input, ElementRef, ViewChild, HostListener, Renderer2 } from '@angular/core';
import { NavigateServiceService } from '../navigate-service.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { NgxImgZoomService } from 'ngx-img-zoom';
import { MenuItem, SelectItem, MessageService } from 'primeng/api';
import { element } from 'protractor';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { Subject } from 'rxjs/internal/Subject';
import { CommonCategories } from '../shared/classes/CommonCategories';
import { CategoriesService } from '../shared/services/categories.service';
import { STEPPER_GLOBAL_OPTIONS } from '@angular/cdk/stepper';

// import {AccordionModule} from 'primeng/accordion';     //accordion and accordion tab
// import {MenuItem} from 'primeng/api'; 


@Component({
  selector: 'app-advice',
  templateUrl: './advice.component.html',
  styleUrls: ['./advice.component.css'],
  providers: [{
    provide: STEPPER_GLOBAL_OPTIONS, useValue: {displayDefaultIndicatorType: false}
  }]
})
export class AdviceComponent implements OnInit {
  selectionChange(e)
  {}
  cars: any[];

  responsiveOptions;
 
itemservies:ItemsServiesDTO[];
selectedItem:string
item:ItemsServiesDTO[];
ArrSelect:ItemsServiesDTO[]=[];
select:SelectItem[]=[];
arrsearch:ItemsServiesDTO[];
deal:number;
previewImageSrc:string;
find:ItemsServiesDTO;
itemServiseDTO1:ItemsServiesDTO[];
itemServiseDTO:ItemsServiesDTO[];
myFullresImage: string;
  myThumbnail: string;
  itemsPerSlide = 5;
  singleSlideOffset = true;
  noWrap = true;
  categories:any[]=[];
  allcategories:CommonCategories[]=[];
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  isEditable = true;
  
  // activeSlideIndex = 0;
  constructor(private servise:NavigateServiceService,
    private _formBuilder: FormBuilder,
    private ngxImgZoom: NgxImgZoomService,
    private ItemsServiesService:ItemsServiesService,
    private CategoriesService:CategoriesService,
    private render:Renderer2,
    private messageService: MessageService) {
      this.responsiveOptions = [
        {
            breakpoint: '1024px',
            numVisible: 3,
            numScroll: 3
        },
        {
            breakpoint: '768px',
            numVisible: 2,
            numScroll: 2
        },
        {
            breakpoint: '560px',
            numVisible: 1,
            numScroll: 1
        }
    ];
  // this.servise.get('api/ItemsServies/GetAll').subscribe(x=>{
   
  // this.item=<ItemsServiesDTO[]>x; console.log(this.item);
  // this.item.forEach(element => {
  //   this.select.push({label:element.ISName,value:element.IsDealId})});
  // });
  
  }
  func(){
    this.servise.NextPAge("deals")
  }
  uploadedFiles: any[] = [];
  onUpload(event) {
    for(let file of event.files) {
        this.uploadedFiles.push(file);
    }
    this.messageService.add({severity: 'info', summary: 'File Uploaded', detail: ''}); }
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }

// search()
// {
// let val=(<HTMLInputElement>event.target).value;
// this.arrsearch=this.itemservies.filter(x=>x.ISName.includes(val));
// console.log(this.arrsearch) 
// }
// filter(v:string){this.select=[];
//   console.log(v)
// this.ArrSelect=this.item.filter(x=>x.ISName.indexOf(v)==0);
// if(this.ArrSelect!=null)
// {this.ArrSelect.forEach(element=>{
// this.select.push({label:element.ISName,value:element.IsDealId})
// })
// }}
// onItemChanged(selectedItem:string)
// {console.log(selectedItem)
//     this.find=this.item.find(data => data.ISName === selectedItem);
    
//   if(this.find!=null)
//    { if (this.find.IsDealId == 1) {
//       this.servise.NextPAge("deals");
//     }
//     else
//     { if (this.find.GroupId == 1)
//        {
//         this.servise.NextPAge("products");
//        }
//        if (this.find.GroupId == 7) {
//       this.servise.NextPAge("services");
//     }}
//   }
// }
}
 