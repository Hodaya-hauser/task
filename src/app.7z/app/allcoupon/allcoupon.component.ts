import { Component, OnInit, HostListener } from '@angular/core';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { NavigateServiceService } from '../navigate-service.service';
import { forEach } from '@angular/router/src/utils/collection';
import { stringify } from 'querystring';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { resolve } from 'url';

@Component({
  selector: 'app-allcoupon',
  templateUrl: './allcoupon.component.html',
  styleUrls: ['./allcoupon.component.css']
})
export class AllcouponComponent implements OnInit {
ItemsServiesDTO1:ItemsServiesDTO[]=[];
item1:ItemsServiesDTO[]=[];
MyCart:ItemsServiesDTO[];
lengh:number;
firstFormGroup: FormGroup;
secondFormGroup: FormGroup;
thirdFormGroup: FormGroup;
  loading: boolean;
  constructor(private ItemsServiesService: ItemsServiesService, private service:NavigateServiceService,private _formBuilder: FormBuilder) { this.getCart()
  }
  check_cart(){
    this.loading=true;
    new Promise((resolve,reject)=>{
      this.ItemsServiesService.GetISByStatus(1).toPromise().then(x=>{
        this.loading=false;
     this.item1=<ItemsServiesDTO[]>x
   
   this.MyCart.forEach(element=>{
   if( ! this.item1.find(item=>item.ISId===element.ISId))
   {
     this.removeFromCart(element)
   }
   })
 })   
    })
 
 }
  getCart(){
    this.MyCart= JSON.parse(localStorage.getItem("cart"));
     if (this.MyCart.length==0)
     this.lengh=null;
     else
     this.lengh=this.MyCart.length;}
  ngOnInit() 
  {
    this.getCart();
    this.check_cart();
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: []
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
    console.log(this.MyCart)
    this.service.item=null;
  }
  removeFromCart(item:ItemsServiesDTO)
  {
    this.MyCart.splice(this.MyCart.findIndex(x=>x.ISId==item.ISId), 1);
    localStorage.setItem("cart",JSON.stringify(this.MyCart));
    if (this.MyCart.length==0)
    this.lengh=null;
    else
    this.lengh=this.MyCart.length;
    localStorage.setItem("buy",JSON.stringify(this.MyCart))
  } 
  selectionChange(e)
  {
    console.log("------------"+ e)
  if(e.selectedIndex==1)
  {
    this.buyconnect();
  }
  }
   buyconnect()
  {this.service.item=this.MyCart;
   this.service.NextPAgeWithParam("buyconnect",0);
  }
 remove(ind:number)
 {
  this.service.item.splice(ind,1);
  this.ItemsServiesDTO1.splice(ind,1);
  (<HTMLElement>event.currentTarget).remove;
 }
  
}