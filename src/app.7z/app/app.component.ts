import { Component, ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NavigateServiceService } from './navigate-service.service';

import { MatBottomSheet } from '@angular/material/bottom-sheet';
import { AllcouponComponent } from './allcoupon/allcoupon.component';
import { OverlayPanel } from 'primeng/overlaypanel';
import { ItemsServiesDTO } from './shared/classes/ItemsServiesDTO';
import { ItemsServiesService } from './shared/services/items-servies.service';

@Component({
  selector: 'app-root', templateUrl: './app.component.html',

  styleUrls: ['./app.component.css']
})
export class AppComponent {
  ItemsServiesDTO1:ItemsServiesDTO[]=[];
item1:ItemsServiesDTO[]=[];
MyCart:ItemsServiesDTO[];
lengh:number;
flagLog:boolean=false;
  onItemChanged(selectedItem:string)
  {
    console.log("kkkkkkkkkkkkkkkkkkk"+selectedItem)
    if(selectedItem!='')
   {  this.lstitem=this.item.filter(x=>x.ISName.includes(selectedItem))
    //  this.lstitem=this.item.filter(x=>x.ISName.indexOf(selectedItem)==0);
      this.find=this.item.find(data => data.ISName === selectedItem);console.log(this.lstitem)
     } 
     else{
         this.lstitem=[];
     }
    if(this.find!=null)
     { 
       
       this.service.NextPAgeWith3Param("buysum",this.find.ISId,4,0);
      //  this.buysum.ngOnInit();
    }
  
  }
  getCart(){
    this.MyCart= JSON.parse(localStorage.getItem("cart"));
    console.log("-------------------cart---------------")
    console.log(this.MyCart)
    // .length==0.length==0
     if (!this.MyCart)
     this.lengh=null;
     else
     this.lengh=this.MyCart.length;}
  ngOnInit() 
  {
    this.getCart()
    console.log(this.MyCart)
    this.service.item=null;
    this.setAd("1");
   
  }
  cheack_cart(){
     this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
      this.item1=<ItemsServiesDTO[]>x
    
    this.MyCart.forEach(element=>{
    if( ! this.item1.find(item=>item.ISId===element.ISId))
    {
      this.removeFromCart(element)
    }
    })
  })
  }
  removeFromCart(item:ItemsServiesDTO)
  {
    this.MyCart.splice(this.MyCart.findIndex(x=>x.ISId==item.ISId), 1);
    localStorage.setItem("cart",JSON.stringify(this.MyCart));
    if (this.MyCart.length==0)
    this.lengh=null;
    else
    this.lengh=this.MyCart.length;
  }  
  buyconnect()
  {
    this.service.item=this.MyCart;
  localStorage.setItem("buy",JSON.stringify(this.MyCart));
  this.allcoupon();
  }
  showCart = false;
  user1: string = null;
  lstitem:ItemsServiesDTO[]=[];
  item:ItemsServiesDTO[];
  find:ItemsServiesDTO;
  public title = 'example';
  ad: any;
  @ViewChild(OverlayPanel, { read: '', static: true }) op;
  click(e){
    this.getCart();
  }
  constructor(private http: HttpClient,
     private r: Router, private service: NavigateServiceService,
      private _bottomSheet: MatBottomSheet
      ,private ItemsServiesService:ItemsServiesService) {
    this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
   
      this.item=<ItemsServiesDTO[]>x; console.log(this.item);})
      this.getCart()
  }
logoff(){
  localStorage.removeItem("user")
 document.getElementById("logoff").style.display="none";
 document.getElementById("logon").style.display="inline-block";
  this.ad=JSON.parse(localStorage.getItem("user"));
  console.log("(((((((((("+this.ad)
  this.flagLog=false;
  this.service.NextPAge("advertisement")
}
  allcoupon() {
    this.cheack_cart();
    this.service.NextPAge("allcoupon");
  }
  getallcoupon() {
    this._bottomSheet.open(AllcouponComponent);
  }

  setAd(ad) {
     let log=JSON.parse(localStorage.getItem("user"))
   if(log)
    {
    this.ad= JSON.parse(localStorage.getItem("user")).name
    document.getElementById("logon").style.display="none";
    document.getElementById("logoff").style.display="inline-block";
    document.getElementById("logoff").textContent=this.ad
    

    this.flagLog=true; 
    }
    else{
      document.getElementById("logoff").style.display="none";
      document.getElementById("logon").style.display="inline-block";
    }
  }
  advertisment(){
    let log=JSON.parse(localStorage.getItem("user"))
      // this.ad = ad;
   if(log)
    {
      this.service.NextPAge("advertisement-area")
    }
    else{
      this.service.NextPAge("advertisement")
    }
  }
  toggleCart() {
    this.op[0].selector.prototype.toggle()
  }

}

