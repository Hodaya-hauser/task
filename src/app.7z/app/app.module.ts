import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { TooltipModule } from 'ngx-bootstrap/tooltip';
import { ModalModule } from 'ngx-bootstrap/modal';
import {
  
  MatOptionModule,
  MatInputModule,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations,
  MatFormFieldControl, MatSelectModule, MatFormFieldModule, MatBottomSheetModule, MatListItem, MatCheckboxModule, MatTableModule, MatPaginatorModule, MatTooltipModule, MatProgressSpinnerModule
} from '@angular/material';
import {MatRadioModule} from '@angular/material/radio';
import {   ReactiveFormsModule } from '@angular/forms';
// import{FormBuilder} from '@angular/forms'FormGroup,, FormControlDirective
// import { NbThemeModule } from '@nebular/theme';
import {NgxPrintModule} from 'ngx-print';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { HttpClient } from 'selenium-webdriver/http';
import { HttpClientModule } from '@angular/common/http';
import { CarouselModule } from 'ngx-bootstrap/carousel';
import { RouterModule } from '@angular/router';
import { path } from './Pathes';
import { FormsModule } from '@angular/forms';
import { AboutComponent } from './about/about.component';
import { ProductsComponent} from './products/products.component';
import { AdviceComponent } from './advice/advice.component';
import { ServicesComponent } from './services/services.component';
import { DealsComponent } from './deals/deals.component';
import { AdvertisementComponent } from './advertisement/advertisement.component';
import { ConnectComponent } from './connect/connect.component';
import { BuysumComponent } from './buysum/buysum.component';
import { BuyconnectComponent } from './buyconnect/buyconnect.component';
import { BuyShowCouponComponent } from './buy-show-coupon/buy-show-coupon.component';
import { DaydealComponent } from './daydeal/daydeal.component';
import { AdvertismentAreaComponent } from './advertisment-area/advertisment-area.component';
import { AdvertisementExtantComponent } from './advertisement-extant/advertisement-extant.component';
import{WriteinfoComponent}from'./writeinfo/writeinfo.component';
import{BesadnoinfoComponent}from'./besadnoinfo/besadnoinfo.component';
import{ChtinfoComponent}from'./chtinfo/chtinfo.component';
import{AllcouponComponent}from'./allcoupon/allcoupon.component';
import { NavigateServiceService } from './navigate-service.service';
import { UserExtandComponent } from './user-extand/user-extand.component';
import { MypipePipe } from './mypipe.pipe';
import {AccordionModule} from 'primeng/accordion'; 
import{ProgressSpinnerModule} from 'primeng/progressspinner'   //accordion and accordion tab
import {MenuItem, MessageService} from 'primeng/api';                 //api
import{StepsModule} from 'primeng/steps';
import {ToastModule} from 'primeng/toast';
import {CardModule} from 'primeng/card';
import{ Carousel} from 'primeng/carousel';
import {DropdownModule } from 'primeng/dropdown';
import { NgxImageZoomModule } from 'ngx-image-zoom';
import { NgxImgZoomModule } from 'ngx-img-zoom';
import {ImageZoomModule} from 'angular2-image-zoom';
import {MenuModule} from 'primeng/menu';
import {MenubarModule} from 'primeng/menubar';
import {OverlayPanelModule} from 'primeng/overlaypanel';
import {ChartModule} from 'primeng/chart';
import {MessagesModule} from 'primeng/messages';
import {MessageModule} from 'primeng/message';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {
  MatButtonModule,
  MatMenuModule,
  MatToolbarModule,
  MatIconModule,
  MatCardModule,MatStepperModule,
  MatHorizontalStepper,MatStepHeader,MatListModule,MatProgressBarModule
} from '@angular/material';
 import {CheckboxModule} from 'primeng/components/checkbox/checkbox';  
 import { MatSliderModule } from '@angular/material/slider';
import { PanelModule } from 'primeng/components/panel/panel';
import { ButtonModule } from 'primeng/components/button/button';
import { RadioButtonModule } from 'primeng/components/radioButton/radioButton';
import { from } from 'rxjs';
import {DataViewModule} from 'primeng/dataview';
import {TableModule} from 'primeng/table';
import { AddAdvertiserComponent } from './add-advertiser/add-advertiser.component';
import { AddItemServiesComponent } from './add-item-servies/add-item-servies.component';
import { HomeComponent } from './home/home.component';
import { CategoryComponent } from './category/category.component';
import {FileUploadModule} from 'primeng/fileupload';
import { StatisticsComponent } from './statistics/statistics.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { ExistItemsComponent } from './exist-items/exist-items.component';

@NgModule({
  declarations: [
  
    AppComponent,
    AboutComponent,
    AdviceComponent,
    ServicesComponent,
    DealsComponent,
    AdvertisementComponent,
    ConnectComponent,
    BuysumComponent,
    BuyconnectComponent,
    BuyShowCouponComponent,
    DaydealComponent,
    ProductsComponent,
    AdvertisementExtantComponent,
    AdvertismentAreaComponent,
    WriteinfoComponent,
    BesadnoinfoComponent,
    ChtinfoComponent,
    AllcouponComponent,
    UserExtandComponent,
    MypipePipe,
    
    AppComponent,
    AboutComponent,
    AdviceComponent,
    ServicesComponent,
    DealsComponent,
    AdvertisementComponent,
    ConnectComponent,
    BuysumComponent,
    BuyconnectComponent,
    BuyShowCouponComponent,
    DaydealComponent,
    ProductsComponent,
    AdvertisementExtantComponent,
    AdvertismentAreaComponent,
    WriteinfoComponent,
    BesadnoinfoComponent,
    ChtinfoComponent,
    AllcouponComponent,
    UserExtandComponent,
    MypipePipe,
    AddAdvertiserComponent,
    AddItemServiesComponent,
    HomeComponent,
    CategoryComponent,
    StatisticsComponent,
    ForgetPasswordComponent,
    ExistItemsComponent,
    
  ],
  imports: [ BrowserModule,MatProgressBarModule,
    ChartModule,
    MatTooltipModule,
    NgxImageZoomModule.forRoot() ,
    CarouselModule,
    CarouselModule.forRoot(),
    BsDropdownModule.forRoot(),
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
MenubarModule,
OverlayPanelModule,
MatCheckboxModule,
MatTableModule,
BrowserModule,
MenuModule,
    HttpClientModule,
    MatRadioModule,
    ToastModule,
    DropdownModule,
    NgxPrintModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forRoot(path),
    StepsModule,
    FormsModule,
    CardModule,CarouselModule,
    BrowserModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,TableModule,
    MatBottomSheetModule,
    AccordionModule,
    PanelModule,
    ButtonModule,
    RadioButtonModule,MatListModule,
    CheckboxModule,
    MatSliderModule,
    DataViewModule,
    BrowserModule,
    HttpClientModule,
    ToastModule,
    RouterModule.forRoot(path),
    StepsModule,
  MatCardModule,
  MatStepperModule,
    ImageZoomModule,
    MatSelectModule,
    MatOptionModule,
    MatInputModule,
    FormsModule,CardModule,
    BrowserModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatMenuModule,
    MatToolbarModule,
    MatIconModule,
    MatCardModule,
    AccordionModule,
    PanelModule,
    ButtonModule,
    RadioButtonModule,
    CheckboxModule,
    MatSliderModule,
    MatFormFieldModule,
    NgxImageZoomModule,
    NgxImgZoomModule,
    MatPaginatorModule,
    MatProgressSpinnerModule,ProgressSpinnerModule,
    MatProgressSpinnerModule,MessagesModule,MessageModule
  ],
  providers: [NavigateServiceService,MessageService],
  bootstrap: [AppComponent]
})

export class AppModule { }

 