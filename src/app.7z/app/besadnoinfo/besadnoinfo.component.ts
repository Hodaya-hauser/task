import { Component, OnInit } from '@angular/core';
import { HttpClient,HttpHandler, HttpHeaders } from '@angular/common/http';

@Component({
  selector: 'app-besadnoinfo',
  templateUrl: './besadnoinfo.component.html',
  styleUrls: ['./besadnoinfo.component.css']
})
export class BesadnoinfoComponent implements OnInit {
  fetchedHtml:any;
  constructor(http:HttpClient) {  
  //   const httpOptions={
  //     headers:new HttpHeaders({
  //       'Access-Control-Allow-Headers': 'Content-Type',
  //       'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  //       'Access-Control-Allow-Origin': '*'
  //     })
  //   }
  //   var headers = new Headers();
  //   headers.append('x-forwarded-host', 'foo');
  //   http.get('https://www.besadno.co.il/about/',httpOptions).subscribe(response => {
  //   this.fetchedHtml = response;
  //   console.log(this.fetchedHtml)
  //  })
  }
  ngOnInit() {
  }

}
