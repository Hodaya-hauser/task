import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NavigateServiceService } from '../navigate-service.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { Users } from '../shared/classes/Users';
import { DatePipe } from '@angular/common';
import { UsersDTO } from '../shared/classes/UsersDTO';
import {MenuItem} from 'primeng/api';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UsersService } from '../shared/services/users.service';
@Component({
  selector: 'app-buy-show-coupon',
  templateUrl: './buy-show-coupon.component.html',
  styleUrls: ['./buy-show-coupon.component.css'],
  providers: [DatePipe]
})
export class BuyShowCouponComponent implements OnInit {
  items: MenuItem[];
  myDate = new Date();
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  isLinear = false;
  id: number;
  constructor(private _formBuilder: FormBuilder,
    private active:ActivatedRoute,
    private service: NavigateServiceService,
    private datePipe: DatePipe,
    private UsersService:UsersService) 
  {
    
   }
 userId:number;
 ISId:number;
 itemServies:ItemsServiesDTO; 
 itemServiesToBuy:ItemsServiesDTO[];
 user:UsersDTO;
  ngOnInit() {
    this.id = this.active.snapshot.params['IS'];
    this.userId=this.active.snapshot.params['user'];
    console.log(this.userId)
    this.items = [
      {label: 'סיכום'},
      {label: 'התחברות'},
      {label: 'הצגת קופון'}
  ];
  this.firstFormGroup = this._formBuilder.group({
    firstCtrl: ['', Validators.required]
  });
  this.secondFormGroup = this._formBuilder.group({
    secondCtrl: ['', Validators.required]
  });
  this.itemServiesToBuy=this.service.item;
  this.itemServiesToBuy=JSON.parse(localStorage.getItem("buy"))
  
  console.log(this.itemServiesToBuy)
  
      this.UsersService.GetByUserId(this.userId).subscribe(res => {
      this.user = <UsersDTO>res;
    }); 
    // if(this.id==0)
    //   {
    //   localStorage.removeItem("cart")
    //   }
}
 }