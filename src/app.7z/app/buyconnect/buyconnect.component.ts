import { Component,  OnInit } from '@angular/core';  
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { Areas } from '../shared/classes/Areas';
import{NavigateServiceService}from '../navigate-service.service';
import { Users } from '../shared/classes/Users';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {MenuItem, MessageService} from 'primeng/api';
import { AreasService } from '../shared/services/areas.service';
import { UsersService } from '../shared/services/users.service';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { ItemsServies } from '../shared/classes/ItemsServies';
@Component({
  selector: 'app-buyconnect',
  templateUrl: './buyconnect.component.html',
  styleUrls: ['./buyconnect.component.css']
})
export class BuyconnectComponent implements OnInit   {
  connect1:FormGroup;
  email = new FormControl('', [Validators.required, Validators.email]);
  nameer = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  tel = new FormControl('', [Validators.required,Validators.maxLength(10),Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')]);
  areaf = new FormControl('', [Validators.required]);
  sug: number;
  ctgr: number;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
submitted:boolean=false;
items: MenuItem[];
arr:number[];
flag:boolean=false;
areas1:Areas[];
id:any="";
are:any='';
userId:number;
flagCategory:boolean=true;
flagArea:boolean=true;
itemServise:ItemsServies;
iditems:number[]=[];
itemservies:ItemsServies[];
buy:ItemsServiesDTO[];
editable:boolean;
adduser:Users={AreaId:0,UserMail:"",UserName:"",UserId:0,UserPhon:undefined,Registration_Date:new Date()};
  show: boolean;
  loading: boolean;
  getErrorMessageemail() {
    if(this.submitted){
      return this.email.hasError('required') ? 'שדה חובה':
        this.email.hasError('email') ? 'מייל לא חוקי':
            '';}
    else{
      this.email.hasError('email') ? 'מייל לא חוקי':
      '';}
  }
  getErrorMessagename() {
    if (this.submitted) {
          return this.nameer.hasError('required') ? 'שדה חובה':
    this.nameer.hasError('maxLenght') ?  'שם לא חוקי':
            '';
    }
    else{
      return     this.nameer.hasError('maxLenght') ? 'שם לא חוקי':
      '';
    }

  }
  getErrorMessagetel() {
  
    return this.tel.hasError('required') ? 'שדה חובה':
    this.tel.hasError('pattern') ? 'מספר הטל אינו תקין' :          
    '';
  }
  getErrorMessageareaf() {

    return this.areaf.hasError('required') ? 'שדה חובה':
              '';
  }
  constructor(private _formBuilder: FormBuilder,
    private http:HttpClient,
    private r:Router,
    private service:NavigateServiceService,
    private active:ActivatedRoute,
    private AreaService:AreasService,
    private ItemsServiesService:ItemsServiesService,
    private UsersService:UsersService,
    private messageService:MessageService) {
      this.loading=true;
      new Promise((resolve,reject)=>{
     this.AreaService.Get().toPromise().then(res=>{
      this.loading=false;
       this.areas1=<Areas[]>res;});    
      })
    
    this.arr=[1,2,3];
    this.id= this.active.snapshot.params['id'];
    this.sug = this.active.snapshot.params['sug'];
    this.ctgr = this.active.snapshot.params['ctgr']; 
  }
    complete:boolean=false;
  ngOnInit() { 
    this.connect1=new FormGroup({
    email : new FormControl('', [Validators.required, Validators.email]),
    nameer : new FormControl('', [Validators.required,Validators.maxLength(50)]),
    tel : new FormControl('', [Validators.required,Validators.maxLength(10),Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')]),
    areaf: new FormControl('', [Validators.required])});
    
    this.show=false;
    
    
    this.items = [
    {label: 'סיכום'},
    {label: 'התחברות'},
    {label: 'הצגת קופון'}
];

this.buy=JSON.parse(localStorage.getItem("buy"));
this.check_buy();


this.secondFormGroup = this._formBuilder.group({
  secondCtrl: []
});
if(this.buy.length==0)
{
 this.messageService.add({severity:'warn', summary:'אין מוצרים לרכישה', detail:''});
}
  }
  check_buy(){
    this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
      this.itemservies=<ItemsServies[]>x;
      this.buy.forEach(element=>{
     if(this.itemservies.find(data=>data.ISId==element.ISId)==null)
     {
      this.buy.splice(this.buy.findIndex(x=>x.ISId==element.ISId), 1);
        localStorage.setItem("buy",JSON.stringify(this.buy));
     }

    })
    })
    console.log(this.buy)
  }
  selectionChange(e)
  {
  if(e.selectedIndex==2)
  {document.getElementById("buttonAdd").click();
  }
  if(e.selectedIndex==0)
  {
    this.check_buy();
    if(this.buy.length!=0)
   { 
     if(this.id!=0)
    {
      if(this.ctgr)
      {
      this.service.NextPAgeWith3Param("buysum",this.id,this.sug,this.ctgr)
      }
      else{  
      this.service.NextPAgeWith2Param("buysum",this.id,this.sug)   
      }
    }
    else{
      this.service.NextPAge("allcoupon")
    }
  }

  }
  }
  connect()
  {
    if(this.buy.length==0)
    {
     this.messageService.add({severity:'warn', summary:'אין מוצרים לרכישה', detail:''});
    }
    else{
    this.onAreaChange();
     this.submitted = false;
if(this.connect1.invalid||!this.flagArea){  
   this.submitted = true;
   
    }
    else{
      this.UsersService.Post(this.adduser).subscribe
      (x=>
       {if(x)
         { this.complete=true;
          this.UsersService.Get( this.adduser.UserMail , this.adduser.UserName).subscribe
         (res => 
           {
             let headers = new HttpHeaders
             ({
              'Content-Type': 'application/json'
             });  
             this.userId= <number>res;
             console.log(JSON.stringify(this.iditems));
                  const frmData = new FormData();
                frmData.append("ItemServies",localStorage.getItem("buy"));
                this.UsersService.Put(this.userId,frmData).subscribe(x=>
                  {
                    if(x==true)
                {
                  if(this.id==0)
                  {
                  localStorage.removeItem("cart")
                  }
                     this.service.NextPAgeWith2Param("buy-show-coupon",this.userId,this.id);      
                }})
             });}
             else{
               this.show=true;
             }
           }
         );
     }  }
}
  userextand()
  {
    if(this.ctgr)
    {
      this.service.NextPAgeWith3Param("user-extand",this.active.snapshot.params['id'],this.sug,this.ctgr);
  }
    else{
      if(this.id!=0)
      {
        this.service.NextPAgeWith2Param("user-extand",this.active.snapshot.params['id'],this.sug);
      }
    else{
      this.service.NextPAgeWithParam("user-extand",this.active.snapshot.params['id'])
    }
  }
}

onAreaChange() {
  this.flagArea=true;
 
  this.adduser.AreaId= this.getSelectedAreaByName(this.are);
  if(this.adduser.AreaId==0&& this.are!=null&& this.are!="")
  {this.flagArea=false; this.adduser.AreaId=0;}
}

getSelectedAreaByName(name: string): number {
  if(this.areas1.find(area => area.name === name)!=null)
  {return this.areas1.find(area => area.name === name).Id;}
  return 0;
}
}
