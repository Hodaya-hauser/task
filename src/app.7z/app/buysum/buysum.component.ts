import { Component, OnInit, ElementRef, Renderer2,  ViewChild} from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { NavigateServiceService } from '../navigate-service.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { MenuItem, MessageService } from 'primeng/api';
import { FormGroup, Validators, FormBuilder } from '@angular/forms';
import { MatBottomSheet} from '@angular/material/bottom-sheet';
import { ToggleCartService } from '../toggle-cart.service';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { NgxImgZoomService } from 'ngx-img-zoom';
@Component({
  selector: 'app-buysum',
  templateUrl: './buysum.component.html',
  styleUrls: ['./buysum.component.css']
})

export class BuysumComponent implements OnInit {
  @ViewChild ('oo', {static: false}) oo:ElementRef;
  // didClick = false;
  selectionChange(e)
  {
    console.log("------------"+ e)
  if(e.selectedIndex==1)
  {
    this.buyconnect();
  }
  }
  enableZoom: Boolean = true;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  thirdFormGroup: FormGroup;
  isLinear = false;
  items: MenuItem[];
  flagSearch:boolean;
  id: number;
  item: ItemsServiesDTO;
  ItemsServiesDTO1: ItemsServiesDTO;
  sug: number;
  myThumbnail; myFullresImage;
  previewImageSrc: string;
  zoomImageSrc: string;
  machine: string;
  opp:HTMLElement ;
  opp1:string;
  loading: boolean=true;
  ctgr:number;
  constructor(private ngxImgZoom: NgxImgZoomService,private render: Renderer2, private http: HttpClient, private r: Router,
    private service: NavigateServiceService, private active: ActivatedRoute,
    private _formBuilder: FormBuilder, private _bottomSheet: MatBottomSheet,
    private ItemsServiesService:ItemsServiesService,
    public toggleCartService: ToggleCartService,
    private messageService: MessageService) {
      this.ngxImgZoom.setZoomBreakPoints([{w: 100, h: 100}, {w: 150, h: 150}, {w: 200, h: 200}, {w: 250, h: 250}, {w: 300, h: 300}])
   
    // this.url = 'api/ItemsServies/' + this.id;


    new Promise((resolve,reject)=>{
      this.active.params.subscribe((params: Params) => {
        this.id = params['id'];
        this.sug = params['sug'];
        this.ctgr =params['ctgr']; 
      })
    //   this.id = this.active.snapshot.params['id'];
    // this.sug = this.active.snapshot.params['sug'];
    // this.ctgr = this.active.snapshot.params['ctgr']; 
     ItemsServiesService.GetById(this.id).subscribe(res => {
     this.loading=false;
      this.ItemsServiesDTO1 = <ItemsServiesDTO>res;
      this.myThumbnail = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
      this.myFullresImage = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
      this.previewImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
      this.zoomImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
       
       })})
  }
    ngAfterViewInit() {
      debugger;
      new Promise((resolve,reject)=>{
        this.id = this.active.snapshot.params['id'];
      this.sug = this.active.snapshot.params['sug'];
      this.ctgr = this.active.snapshot.params['ctgr']; 
        this.ItemsServiesService.GetById(this.id).subscribe(res => {
       this.loading=false;
        this.ItemsServiesDTO1 = <ItemsServiesDTO>res;
        this.myThumbnail = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
        this.myFullresImage = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
        this.previewImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
        this.zoomImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
         
         })})
    }
  ngOnInit() {
    
    new Promise((resolve,reject)=>{
      this.active.params.subscribe((params: Params) => {debugger;
        this.id = params['id'];
        this.sug = params['sug'];
            this.ctgr =params['ctgr']
    //   this.id = this.active.snapshot.params['id'];
    // this.sug = this.active.snapshot.params['sug'];
    // this.ctgr = this.active.snapshot.params['ctgr']; 
     this.ItemsServiesService.GetById(this.id).subscribe(res => {
     this.loading=false;
      this.ItemsServiesDTO1 = <ItemsServiesDTO>res;
      this.myThumbnail = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
      this.myFullresImage = "data:image/jpg;base64," + this.ItemsServiesDTO1.ImageUrl;
      this.previewImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
      this.zoomImageSrc = 'data:image/jpg;base64,' + this.ItemsServiesDTO1.ImageUrl;
       
       })})}) 
    if(this.ctgr==0 && this.sug==4)
    {
this.flagSearch=false;

    }
    else
    {
      this.flagSearch=true;
    }
    this.items = [
      { label: 'סיכום' },
      { label: 'התחברות' },
      { label: 'הצגת קופון' }
    ];
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: []
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
    this.thirdFormGroup = this._formBuilder.group({
      thirdCtrl: ['', Validators.required]
    });
  }
  buyconnect() {
    this.service.item = [];
    this.service.item[0] = this.ItemsServiesDTO1;
    console.log(this.service.item)
    if(this.ctgr)
   { 
     this.service.NextPAgeWith3Param("buyconnect", this.id,this.sug,this.ctgr);
    }
   else{console.log("ctgr")
this.service.NextPAgeWith2Param("buyconnect", this.id,this.sug);
   }
  }
  deals() {
    if (this.sug == 3) {
      this.service.NextPAge("deals");
    }
    if (this.sug == 1) {
      this.service.NextPAge("products");
    }
    if (this.sug == 2) {
      this.service.NextPAge("services");
    }
    if (this.sug == 0) {
      this.service.NextPAge("");
    }
    if(this.sug==4)
    {
      this.service.NextPAgeWithParam("category",this.ctgr);
    }
  }
  addToCart(event) {
    let MyCart: ItemsServiesDTO[] = JSON.parse(localStorage.getItem("cart"));
    let MyCart1: ItemsServiesDTO[] = [];
    if (MyCart == null) {
      MyCart1[0] = this.ItemsServiesDTO1;
      this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
    }
    else {
      MyCart1 = MyCart
      if (MyCart1.find(x => x.ISId == this.ItemsServiesDTO1.ISId) == null) 
      { MyCart1.push(this.ItemsServiesDTO1) 
        this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
      }
      else {
        this.messageService.add({severity:'warn', summary:'המוצר קיים כבר בסל ', detail:''});
        // alert("לא ניתן להוסיף לסל את אותו מוצר פעמים");
      }
      // this._bottomSheet.open(AllcouponComponent);
    }

    localStorage.setItem("cart", JSON.stringify(MyCart1));
    // לבדוק
  //   this.opp=<HTMLElement ><unknown>document.querySelector("#oo")
  //   let e:HTMLElement =document.querySelector("#oo");
  // e.click();
  // -------------------------------------------------------------------
  }
  click(){
    this.ngOnInit();
  }
}
