import { Component, OnInit } from '@angular/core';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { CommonCategories } from '../shared/classes/CommonCategories';
import { SelectItem, MessageService } from 'primeng/api';
import { NavigateServiceService } from '../navigate-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { MatBottomSheet } from '@angular/material';
import { HttpClient } from '@angular/common/http';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { CategoriesService } from '../shared/services/categories.service';
import { ActiveDescendantKeyManager } from '@angular/cdk/a11y';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  openForm() {
    document.getElementById("myForm").style.display = "inline-block";
  }
  
   closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
categoryId:number;
  sug:number=3;
  ItemsServiesDTO1:ItemsServiesDTO[];
  inputISName:string="";
inputAd:string="";
inputArea:string="";
inputCategory:number=0
  ItemServiesDTO2:ItemsServiesDTO[];
categories:CommonCategories[];
strCategor:SelectItem[]=[{label:"כל הקטגוריות", value:0}];
  loading: boolean=true;
  // customer: CustomCartItem;
  constructor(private service:NavigateServiceService,
    private r:Router,
    private _bottomSheet: MatBottomSheet,
    private http:HttpClient,
    private CategoriesService:CategoriesService,
    private active:ActivatedRoute,
    private ItemsServiesService:ItemsServiesService,
    private messageService: MessageService) 
  {  this.categoryId=this.active.snapshot.params['id'];
  console.log(this.categoryId)
    ItemsServiesService.GetByCategory(this.categoryId).toPromise().then(ItemsServiesDTO1 => this.ItemsServiesDTO1 = <ItemsServiesDTO[]>ItemsServiesDTO1);
    service.sug=4;
  }
  ngOnInit() 
  { 
      
    this.CategoriesService.Get().subscribe(res=>{
    
      
    this.categories=<CommonCategories[]>res
    this.categories.forEach(element =>{
      // if(element.GroupId==1) 
      this.strCategor.push({label: element.CategoryName,value: element.CategoryId
    })
  
    this.service.item=null;
    new Promise((resolve,reject)=>{
      this.categoryId=this.active.snapshot.params['id']; this.ItemsServiesService.GetByCategory(this.categoryId).toPromise().then(res=>{
     console.log(this.categoryId)
        this.loading=false;
      this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
       this.ItemServiesDTO2=this.ItemsServiesDTO1
       
       })})
       }); 
  })
  }
  addToCart(item:ItemsServiesDTO)
  {item.CountWatch++;
    this.ItemsServiesService.Put(item).subscribe();
    let MyCart:ItemsServiesDTO[]=JSON.parse(localStorage.getItem("cart"));
    let MyCart1:ItemsServiesDTO[]=[];
    if (MyCart==null)
    {
     MyCart1[0]=item
     this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
    }
    else
    {
      MyCart1=MyCart
      if (MyCart1.find(x=>x.ISId==item.ISId)==null)
      {
        MyCart1.push(item)
        this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
      }
      else
      {
        this.messageService.add({severity:'warn', summary:'המוצר קיים כבר בסל ', detail:''});
        // alert("לא ניתן להוסיף לסל את אותו מוצר פעמים");
      }
      // this._bottomSheet.open(AllcouponComponent);
    }
    localStorage.setItem("cart",JSON.stringify(MyCart1));
  }
  conect(item:ItemsServiesDTO)
  {item.CountWatch++;
    this.ItemsServiesService.Put(item).subscribe();
    let buy:ItemsServiesDTO[]=[];
    buy[0]=item;
    localStorage.setItem("buy",JSON.stringify(buy))
    this.service.NextPAgeWith3Param("buysum",item.ISId,this.service.sug,this.categoryId);
  }
  searchISName()
{
this.inputISName=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchAd()
{
this.inputAd=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.Ad.includes(this.inputAd));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));

this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchArea()
{
this.inputArea=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.Area.includes(this.inputArea));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchCategory(event){
    this.inputCategory = event.value;
    if(this.inputCategory==0)
    this.ItemsServiesDTO1=this.ItemServiesDTO2;
    else
    this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.CategorId==this.inputCategory);
    this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
  }

}
