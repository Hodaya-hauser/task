import { Component, OnInit } from '@angular/core';
import {InputTextModule} from 'primeng/inputtext';
import { FormControl, Validators, FormGroup, FormGroupDirective } from '@angular/forms';
import { Alert } from 'selenium-webdriver';
import { HttpClient } from '@angular/common/http';
import { Contact } from '../shared/classes/Contact';
import { ContactService } from '../shared/services/contact.service';
import { MessageService } from 'primeng/api';
@Component({
  selector: 'app-connect',
  templateUrl: './connect.component.html',
  styleUrls: ['./connect.component.css']
})
export class ConnectComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  fname = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  tel1 = new FormControl('', [Validators.required,Validators.maxLength(10),Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')]);
  adForm:FormGroup;
  contact: Contact = { ContactId:0,ContactName:"",ContactMail:"",ContactPhon:""}
  
  getErrorMessageemail() {
    
    if(this.submitted){
    return this.email.hasError('required') ?'שדה חובה': 
    // 'You must enter a value' :
        this.email.hasError('email') ? 'מייל לא חוקי':
        // 'Not a valid email' :
            '';}
            else{
             return this.email.hasError('email') ? 'מייל לא חוקי':
            //  'Not a valid email' :
             '';
            }
  } 
  getErrorMessagefname() {
    if(this.submitted){
          return this.fname.hasError('required') ? 'שדה חובה': 
          // 'You must enter a value' :
    this.fname.hasError('maxLenght') ? 'שם לא חוקי':
    // 'Not a valid email' :
            '';
    } 
  
    }
    getErrorMessagetel1() {
      return this.tel1.hasError('required') ?  'שדה חובה': 
      // 'You must enter a value' :
      this.tel1.hasError('pattern') ? 'מס הטל לא חוקי' :
                '';
    }
 
  submitted:boolean=false;
  add(formDirective: FormGroupDirective){
    //  this.getErrorMessagelname();
      this.submitted = false;
      // if(!form.valid || !this.flagArea|| !this.flagCategory) {
        if(this.adForm.invalid){
        this.submitted = true;
      }
      else{
        this.ContactService.Post( this.contact).subscribe(x => {
          this.messageService.add({severity:'info', summary:'הפרטים נשמרו במערכת, אנו נחזור אליך בהקדם', detail:''});
          formDirective.resetForm();
        this.adForm.reset()
          this.contact= { ContactId:0,ContactName:"",ContactMail:"",ContactPhon:""} });
      }
    }
  
  constructor(private http:HttpClient,
    private ContactService:ContactService,
    private messageService: MessageService) { }
 
  ngOnInit() { this.adForm = new FormGroup({
    email : new FormControl('', [Validators.required, Validators.email]),
    fname : new FormControl('', [Validators.required, Validators.maxLength(50)]),
    tel1 : new FormControl('', [Validators.required, Validators.maxLength(10), Validators.pattern('[0]{1}[1-9]{1}[0-9]{7,}')])
  });
  }
}
export class InputTextDemo {

  text: string;

  disabled: boolean = true;

  toggleDisabled() {
      this.disabled = !this.disabled;
  }

  
}
