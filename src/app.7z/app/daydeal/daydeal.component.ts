import { Component, OnInit, Output, Input } from '@angular/core';

import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { NavigateServiceService } from '../navigate-service.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import {MatBottomSheet, MatBottomSheetRef} from '@angular/material/bottom-sheet';
import { AllcouponComponent } from '../allcoupon/allcoupon.component';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { resolve } from 'url';
import { MessageService } from 'primeng/api';
// import { ItemsServiesDTO } from 'src/app1/ItemsServiesDTO';
@Component({
  selector: 'app-daydeal',
  templateUrl: './daydeal.component.html',
  styleUrls: ['./daydeal.component.css']
})
export class DaydealComponent implements OnInit {
  loading:boolean;
  HotDeal1:ItemsServiesDTO;
  constructor(private http:HttpClient,
    private r:Router,
    private service:NavigateServiceService,
    private _bottomSheet: MatBottomSheet,
    private ItemsServiesService:ItemsServiesService,
    private messageService: MessageService) {
      new Promise((resolve,reject)=>{ItemsServiesService.GetDayDeal().toPromise().then(res=>{
        this.loading=false;
        this.HotDeal1=<ItemsServiesDTO>res;})})
   // this.http.get('api/HotDeal').subscribe(res=>{this.HotDeal1=<HotDeal>res;}) 
  //  ItemsServiesService.GetDayDeal().subscribe(res=>{this.HotDeal1=<ItemsServiesDTO>res;});
   }

   addToCart(item:ItemsServiesDTO){
    let MyCart:ItemsServiesDTO[]=JSON.parse(localStorage.getItem("cart"));
let MyCart1:ItemsServiesDTO[]=[];
if (MyCart==null)
{
  MyCart1[0]=item;
  this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
}
else{
  MyCart1=MyCart
  if (MyCart1.find(x=>x.ISId==item.ISId)==null)
  {MyCart1.push(item);
    this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
  }
  else
  {
    this.messageService.add({severity:'warn', summary:'המוצר קיים כבר בסל ', detail:''});
    // alert("לא ניתן להוסיף לסל את אותו מוצר פעמים");
  }
  // this._bottomSheet.open(AllcouponComponent);
}

  localStorage.setItem("cart",JSON.stringify(MyCart1));
  }
  
  conect(item:ItemsServiesDTO)
  {
    let buy:ItemsServiesDTO[]=[];
    buy[0]=item;
    localStorage.setItem("buy",JSON.stringify(buy));
    item.CountWatch++;
    this.ItemsServiesService.Put(item).subscribe();
    this.service.NextPAgeWith2Param("buysum",item.ISId,this.service.sug);
  }
  ngOnInit() {
    
this.loading=true;
  }
}
