import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExistItemsComponent } from './exist-items.component';

describe('ExistItemsComponent', () => {
  let component: ExistItemsComponent;
  let fixture: ComponentFixture<ExistItemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExistItemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExistItemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
