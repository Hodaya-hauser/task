import { Component, OnInit } from '@angular/core';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';

@Component({
  selector: 'app-exist-items',
  templateUrl: './exist-items.component.html',
  styleUrls: ['./exist-items.component.css']
})
export class ExistItemsComponent implements OnInit {
existitems:ItemsServiesDTO[];
  constructor() { }

  ngOnInit() {
    this.existitems=JSON.parse(localStorage.getItem("buy"));
  }

}
