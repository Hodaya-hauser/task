import { Component, OnInit } from '@angular/core';
import { FormControl, Validators, FormGroup, FormGroupDirective } from '@angular/forms';
import { AdvertiserDetails } from '../shared/classes/AdvertiserDetails';
import { ActivatedRoute, Router } from '@angular/router';
import { AdvertiserDetailsService } from '../shared/services/advertiser-details.service';
import { NavigateServiceService } from '../navigate-service.service';
import { HttpClient } from '@angular/common/http';
import { MessageService } from 'primeng/api';
const lengthOfCode=10;
@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.css']
})

export class ForgetPasswordComponent implements OnInit {
  possible:string = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890,./;'[]\=-)(*&^%$#@!";
 
  makeRandom(lengthOfCode: number, possible: string) {
   let text = "";
  
   for (let i = 0; i < lengthOfCode; i++) {
     text += possible.charAt(Math.floor(Math.random() * possible.length));
   } console.log(text)
     return text;
 }
  adForm: FormGroup;
  email = new FormControl('', [Validators.required, Validators.email]);
  nameer = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  advertisment:AdvertiserDetails;
  showErrorMass: boolean=false;
  getErrorMessage() {
    if(this.submitted){
    return this.email.hasError('required') ? 'שדה חובה':
        this.email.hasError('email') ? 'מייל לא חוקי':
            '';}
            else{
             return this.email.hasError('email') ? 'מייל לא חוקי':
             '';
            }
  }
  getErrorMessagename() {
    if(this.submitted){
    return this.nameer.hasError('required') ? 'שדה חובה':
    this.nameer.hasError('maxLenght') ? 'שם לא חוקי':
            '';
  }}
  submitted:boolean=false;
  mail: string = "";
  name: string = "";
  password: string = "";
  public show: boolean = false;
  id:number;
  constructor(private http:HttpClient,
    private r:Router,
    private service:NavigateServiceService,
    private AdvertismentDetailsServies:AdvertiserDetailsService,
    private active:ActivatedRoute , private messageService:MessageService) { }
add(formDirective: FormGroupDirective){
  this.submitted = false;
  if (this.adForm.invalid) {
    this.submitted = true;
  }
  else { this.AdvertismentDetailsServies.GetByMailName(this.mail.toString(),this.name.toString()).subscribe(res => 
    {this.advertisment=<AdvertiserDetails>res
      console.log(this.advertisment)    //  &&this.password=="1234"
     if(this.advertisment!=null )
     {   this.advertisment.Adkod=this.makeRandom(lengthOfCode, this.possible);
      
      this.AdvertismentDetailsServies.Put(this.advertisment).subscribe(x=>{
        formDirective.resetForm();
        this.adForm.reset()
        this.show = false;
       this.messageService.add({severity:'info', summary:'סיסמא חדשה נשלחה למייל שלך', detail:''});})
      
     }
     else 
     {
       this.show = true;
     }
    });}}

  ngOnInit() {
    this.adForm = new FormGroup({
      email : new FormControl('', [Validators.required, Validators.email]),
      nameer : new FormControl('', [Validators.required, Validators.maxLength(50)])
    });
  }

}
