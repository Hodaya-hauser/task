import { Component, OnInit } from '@angular/core';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { CategoriesService } from '../shared/services/categories.service';
import { CommonCategories } from '../shared/classes/CommonCategories';
import { NavigateServiceService } from '../navigate-service.service';
import { MessageService } from 'primeng/api';
import { AllcouponComponent } from '../allcoupon/allcoupon.component';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  itemServiseDTO: ItemsServiesDTO[];
  myThumbnail: string;
  allcategories: CommonCategories[];
  categories: any[]=[];
  itemServiseDTO1: ItemsServiesDTO[];
  loading: boolean;
  allitems:ItemsServiesDTO[];
  HotDeal1: ItemsServiesDTO;
  constructor(private ItemsServiesService:ItemsServiesService,
    private CategoriesService:CategoriesService,
    private service:NavigateServiceService,
    private messageService: MessageService) { }
  ngOnInit() {
    this.loading=true;
    this.ItemsServiesService.sug(3).subscribe(x=>
     {
      this.itemServiseDTO=<ItemsServiesDTO[]>x;
      // if(this.itemServiseDTO[0])
      // {
      // this.myThumbnail="data:image/jpg;base64,"+this.itemServiseDTO[0].ImageUrl
      // }
      this.CategoriesService.Get().subscribe(x=>
       {
         this.allcategories=<CommonCategories[]>x;
         this.allcategories.forEach(element=>
           {
             this.ItemsServiesService.GetByCategory(element.CategoryId).subscribe(x=>
               {
                 this.itemServiseDTO1=<ItemsServiesDTO[]>x  
                 if(this.itemServiseDTO1[0]!=null)
                 {console.log(this.itemServiseDTO1[0].Image)
                   this.categories.push(
                   {
                     ImageUrl: this.itemServiseDTO1[0].ImageUrl,
                     CategoryId: element.CategoryId,
                     CategoryName: element.CategoryName
                  
                  
                   })
                 }
               
               } )
                 
           }) 
           new Promise((resolve,reject)=>{
             this.ItemsServiesService.GetAll().toPromise().then(res=>{
                  this.loading=false;
                  this.allitems=<ItemsServiesDTO[]>res;
                 this.HotDeal1= this.allitems.find(x=>x.IsDealId==2);
                 this.ItemsServiesService.GetDayDeal().subscribe(x=>this.HotDeal1=<ItemsServiesDTO>x)
               console.log(this.HotDeal1)   })
              })
           
       })
      
     }) 
}
addToCart(item:ItemsServiesDTO){
  let MyCart:ItemsServiesDTO[]=JSON.parse(localStorage.getItem("cart"));
let MyCart1:ItemsServiesDTO[]=[];
if (MyCart==null)
{
MyCart1[0]=item;
this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
}
else{
MyCart1=MyCart
if (MyCart1.find(x=>x.ISId==item.ISId)==null)
{MyCart1.push(item);
  this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
}
else
{
  // alert("לא ניתן להוסיף לסל את אותו מוצר פעמים");
  this.messageService.add({severity:'warn', summary:'המוצר קיים כבר בסל ', detail:''});
}
// this._bottomSheet.open(AllcouponComponent);
}

localStorage.setItem("cart",JSON.stringify(MyCart1));
}

conect(item:ItemsServiesDTO)
{
  this.service.sug=0;
  let buy:ItemsServiesDTO[]=[];
  buy[0]=item;
  localStorage.setItem("buy",JSON.stringify(buy));
  this.service.NextPAgeWith2Param("buysum",item.ISId,0);
}
category(CategoryId:number)
{
  this.service.NextPAgeWithParam("category",CategoryId);
}
}
