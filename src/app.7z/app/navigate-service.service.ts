import { Injectable } from '@angular/core';
import {HttpClient}from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { ItemsServiesDTO } from './shared/classes/ItemsServiesDTO';
@Injectable({
  providedIn: 'root'
})

export class NavigateServiceService {
  constructor(private http:HttpClient,private r:Router,private active:ActivatedRoute) {
     }
     existitms:ItemsServiesDTO[];
    item:ItemsServiesDTO[]=[];
    sug:number;
  NextPAge(page:string)
  {
    this.r.navigate([page]);
  }
  NextPAgeWithParam(page:string, id:any)
  { 
    this.r.navigate([page,id]); 
  }
  NextPAgeWith2Param(page:string, param1:number, param2:number)
  { this.r.navigate([page,param1,param2]); 
  }
  NextPAgeWith3Param(page:string, param1:number, param2:number,param3:number)
  { this.r.navigate([page,param1,param2,param3]); 
  }
}