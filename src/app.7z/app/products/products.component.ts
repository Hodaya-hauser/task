import { Component, OnInit, HostListener } from '@angular/core';
import { JsonpClientBackend, HttpClient } from '@angular/common/http';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { NavigateServiceService } from '../navigate-service.service';
import { Router } from '@angular/router';
import { Areas } from '../shared/classes/Areas';
import { AdvertiserDetails } from '../shared/classes/AdvertiserDetails';
import { CommonCategories } from '../shared/classes/CommonCategories';
import {MatBottomSheet, MatBottomSheetRef} from '@angular/material/bottom-sheet';
import { AllcouponComponent } from '../allcoupon/allcoupon.component';
import { SelectItem, MessageService, Message } from 'primeng/api';
import { CategoriesService } from '../shared/services/categories.service';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { resolve } from 'url';

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css'],providers:[MessageService]
})
export class ProductsComponent implements OnInit {
  openForm() {
    document.getElementById("myForm").style.display = "inline-block";
  }
  
   closeForm() {
    document.getElementById("myForm").style.display = "none";
  }
  // msgs: Message[] = [];
inputISName:string="";
color:string="#007ad9"
inputAd:string="";
inputArea:string="";
inputCategory:number=0
  ItemServiesDTO2:ItemsServiesDTO[];
categories:CommonCategories[];
strCategor:SelectItem[]=[{label:"כל הקטגוריות", value:0}];
ItemsServiesDTO1:ItemsServiesDTO[];
loading:boolean=true;
  constructor(private service:NavigateServiceService,
    private r:Router,private _bottomSheet: MatBottomSheet,
    private http:HttpClient,
    private CategoriesService:CategoriesService,
    private ItemsServiesService:ItemsServiesService,
    private messageService: MessageService) {
    //   ItemsServiesService.sug(1).subscribe(res=>{this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
    // this.ItemServiesDTO2=this.ItemsServiesDTO1
    
    // });
    new Promise((resolve,reject)=>{ ItemsServiesService.sug(1).toPromise().then(res=>{
     this.loading=false;
     this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
      this.ItemServiesDTO2=this.ItemsServiesDTO1
      
      })})
    service.sug=1;
  }
  searchISName()
{
this.inputISName=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchAd()
{
this.inputAd=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.Ad.includes(this.inputAd));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));

this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchArea()
{
this.inputArea=(<HTMLInputElement>event.target).value;
this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.Area.includes(this.inputArea));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
if(this.inputCategory!=0)
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.CategorId==this.inputCategory);
}
searchCategory(event){
    this.inputCategory = event.value;
    if(this.inputCategory==0)
    this.ItemsServiesDTO1=this.ItemServiesDTO2;
    else
    this.ItemsServiesDTO1=this.ItemServiesDTO2.filter(x=>x.CategorId==this.inputCategory);
    this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Area.includes(this.inputArea));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.ISName.includes(this.inputISName));
this.ItemsServiesDTO1=this.ItemsServiesDTO1.filter(x=>x.Ad.includes(this.inputAd));
  }
  ngOnInit() {
    this.CategoriesService.Get().subscribe(res=>{
    this.categories=<CommonCategories[]>res
    this.categories.forEach(element =>{
      if(element.GroupId==1) 
      this.strCategor.push({label: element.CategoryName,value: element.CategoryId
    })
   }); 
  })
    this.service.item=null;
    this.ItemsServiesService.sug(1).subscribe(res=>{this.ItemsServiesDTO1=<ItemsServiesDTO[]>res;
      this.ItemServiesDTO2=this.ItemsServiesDTO1})
  }
  conect(item:ItemsServiesDTO)
  {

    item.CountWatch++;
    this.ItemsServiesService.Put(item).subscribe();
    let buy:ItemsServiesDTO[]=[];
    buy[0]=item;
    localStorage.setItem("buy",JSON.stringify(buy))
    this.service.NextPAgeWith2Param("buysum",item.ISId,this.service.sug); 
    
  }
  addToCart(item:ItemsServiesDTO){
    item.CountWatch++;
    this.ItemsServiesService.Put(item).subscribe();
let MyCart:ItemsServiesDTO[]=JSON.parse(localStorage.getItem("cart"));
let MyCart1:ItemsServiesDTO[]=[];
if (MyCart==null)
{
  MyCart1[0]=item;
  this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''});
}
else{
  MyCart1=MyCart
  if (MyCart1.find(x=>x.ISId==item.ISId)==null)
  {
    MyCart1.push(item);
    this.messageService.add({severity:'info', summary:'המוצר נוסף לסל בהצלחה', detail:''}); 
  }
  else
  {
    this.messageService.add({severity:'warn', summary:'המוצר קיים כבר בסל ', detail:''});
    // alert("לא ניתן להוסיף לסל את אותו מוצר פעמים");
  }
  // this._bottomSheet.open(AllcouponComponent);
}

  localStorage.setItem("cart",JSON.stringify(MyCart1));
  }
  
}
