export class AdvertiserDetails{
     AdPhon: string;
 AdMail: string;
 AdName: string;
 AdCategory: number;
 Adtext: string;
 AdId:number ;
 AreaId:number ;
  Adkod:string;
   AdStatus:number;
}