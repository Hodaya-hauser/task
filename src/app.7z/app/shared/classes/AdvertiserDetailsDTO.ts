export class AdvertiserDetailsDTO{
      AdName: string;
      AdPhon: string; 
      AdMail :string; 
      AdCategory :number;
      Adtext :string; 
      AdId :number;
      Area: string; 
      Adkod:string; 
      AdStatus: number;
      AreaId :number;
      Category:string;
}