export class Areas{
     Id:number; 
    name:string; 
     C_type:number; 
}