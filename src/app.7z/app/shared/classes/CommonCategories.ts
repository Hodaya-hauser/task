export class CommonCategories{
     CategoryId:number ;
 CategoryName: string;
 GroupId:number ;

}