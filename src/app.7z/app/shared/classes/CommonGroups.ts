export class CommonGroups{
     GroupId:number ;
 GroupName:string ;

}