export class Contact{
     ContactId :number;
      ContactName :string;
       ContactMail :string;
       ContactPhon :string;
}