export class IsDeal{
     IsDealId:number ;
 IsDealName:string ;

}