export class ItemsServies
    {      ISId :number;
      ISName :string;
      CategorId :number;
      IsDealId :number;
      discount :string;
      AreaId :number;
      AdId:number;

      CouponId :string;
      Image :string;
      Status:number;
      ISdetails: string;
      CountWatch: number;
      CountBuyer: number;
    }