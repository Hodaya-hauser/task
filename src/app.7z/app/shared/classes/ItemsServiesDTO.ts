// import { HexBase64BinaryEncoding } from 'crypto';

export class ItemsServiesDTO
    {
         ISId:number ;
         ISName:string ;
        Categor:string;
         IsDealId:number;
         discount:string ;
         Area:string ;
         Ad:string ;
          CouponId:string;
          CategorId :number;
          AreaId :number;
          Image :string;
          ImageUrl:ArrayBuffer ;
          Status:number;
          AdId:number;
          IsDeal:string;
            ISdetails: string;
            CountWatch: number;
            CountBuyer: number;
             GroupId:number;
    }