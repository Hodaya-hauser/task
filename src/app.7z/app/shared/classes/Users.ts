import { Data } from '@angular/router';


export class Users{
      UserId :number;
         UserName:string;
          UserPhon:string;
          UserMail:string; 
          AreaId:number; 
          Registration_Date:Data;
    }