export class UsersDTO{
    UserId :number;
       UserName:string;
        UserPhon:number;
        UserMail:string; 
        AreaId:number; 
        Area:string; 
  }