import { TestBed } from '@angular/core/testing';

import { AdvertiserDetailsService } from './advertiser-details.service';

describe('AdvertiserDetailsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: AdvertiserDetailsService = TestBed.get(AdvertiserDetailsService);
    expect(service).toBeTruthy();
  });
});
