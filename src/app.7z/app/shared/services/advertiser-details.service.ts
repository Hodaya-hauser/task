import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AdvertiserDetails } from '../classes/AdvertiserDetails';

@Injectable({
  providedIn: 'root'
})
export class AdvertiserDetailsService {

  constructor(private http:HttpClient) { }
  // Get()
  // {
  //   return this.http.get("api/AdvertiserDetails");
  // }
  // GetById(id :number)
  // {
  //   return this.http.get("api/Ad/"+id);
  // }
  GetByMailName( AdvertiserMail:string,  AdvertiserName:string)
  {
    return this.http.get("/api/Ad/"+AdvertiserMail+'/'+AdvertiserName);
  }
  GetStatus(status:number)
  {
    return this.http.get("/api/AdvertiserDetails/GetStatus/"+status);
  }
  Post( newAdvertiser:AdvertiserDetails)
  {
    return this.http.post("/api/Advertisment",newAdvertiser);
  }
  Put(  AdvertiserDetails:AdvertiserDetails)
  {
    return this.http.put("/api/AdvertiserDetails",AdvertiserDetails);
  }
}
