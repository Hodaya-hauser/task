import { TestBed } from '@angular/core/testing';

import { ItemsServiesService } from './items-servies.service';

describe('ItemsServiesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ItemsServiesService = TestBed.get(ItemsServiesService);
    expect(service).toBeTruthy();
  });
});
