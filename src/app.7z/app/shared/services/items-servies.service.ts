import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ItemsServies } from '../classes/ItemsServies';

@Injectable({
  providedIn: 'root'
})

export class ItemsServiesService {
  frmData :FormData;
  constructor(private http:HttpClient) { }
  GetDayDeal()
  {
    return this.http.get("api/ItemsServies");
  }
  GetAll()
  {
    return this.http.get("api/ItemsServies/GetAll");
  }
  sug( id:number)
  {
    return this.http.get("api/ItemsServies/sug/"+id);
  }
  GetISByStatus( status:number)
  {
    return this.http.get("api/ItemsServies/status/"+status);
  }
  // GetDeal()
  // {
  //   return this.http.get("api/ItemsServies/GetDeal");
  // }
  GetById(id:number)
  {
    return this.http.get("api/ItemsServies/GetById/"+id);
  }
  GetByAdDTO( AdId:number)
  {
    return this.http.get("api/ItemsServies/GetByAdDTO/"+AdId);
  }
  // GetByAd( AdId:number)
  // {
  //   return this.http.get("api/ItemsServies/GetByAd/"+AdId);
  // }
  GetByCategory(CategoryId:number)
  {
    return this.http.get("api/ItemsServies/GetByCategory/"+CategoryId);
  }
      
  Put( itemsServies:ItemsServies)
  {
    return this.http.put("api/ItemsServies",itemsServies);
  }
  UploadFiles1( id:number,frmData:FormData)
  { 
    return this.http.put("/api/ItemsServies/put/UploadFiles1/"+id,frmData);
  }
  Post( itemsServies:ItemsServies)
  {
    return this.http.post("api/ItemsServies",itemsServies);
  }
  Delete(id:number)
  {
    return this.http.delete("api/ItemsServies/Delete/"+id);
  }
}
