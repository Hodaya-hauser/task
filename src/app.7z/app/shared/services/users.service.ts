import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Users } from '../classes/Users';

@Injectable({
  providedIn: 'root'
})
export class UsersService {
  constructor(private http:HttpClient) { }
  Get( UserMail:string,  UserName:string)
  {
    return this.http.get("/api/Users/"+UserMail+"/"+UserName);
  }
  GetByUserId( Userid:number)
  {
    return this.http.get("/api/Users/GetByUserId/"+Userid);
  }
  Post( user:Users)
  {
    return this.http.post("/api/Users",user);
  }
  Put( id:number,frmData:FormData)
  {
    return this.http.put("/api/User/Put1/"+id,frmData);
  }
}
