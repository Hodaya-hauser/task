import { Component, OnInit } from '@angular/core';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-statistics',
  templateUrl: './statistics.component.html',
  styleUrls: ['./statistics.component.css']
})
export class StatisticsComponent implements OnInit {

  labels:string[]=[];
  dataBar1:number[]=[];
  dataBar2:number[]=[];
  dataBar: any;
  dataPie:any;
  dataPie1:number=0;
  dataPie2:number=0;
  loading:boolean=true;
  id:number;
  itemServise:ItemsServiesDTO[];
  optionsPie: { title: { display: boolean; text: string; fontSize: number; }; legend: { position: string; }; };
  optionsBar: { title: { display: boolean; text: string; fontSize: number; }; legend: { position: string; }; };
  constructor(private ItemsServiesService:ItemsServiesService,private active:ActivatedRoute){
    // this.id=active.snapshot.params['id'];
    this.id=JSON.parse(localStorage.getItem("user")).id;
    if(this.id)
   { new Promise((resolve,reject)=>{
    ItemsServiesService.GetByAdDTO(this.id).toPromise().then(x=>{
      this.loading=false;
      this.itemServise=<ItemsServiesDTO[]>x;
      this.itemServise.forEach(element=>{
          if(element.Status==1)
        {this.labels.push(element.ISName)
        this.dataBar1.push(element.CountWatch)
        this.dataBar2.push(element.CountBuyer)
        this.dataPie1+=element.CountWatch;
        this.dataPie2+=element.CountBuyer;}
      })
       this.dataBar = {
      labels: this.labels,
      datasets: [
          {
              label: 'כמות צפיות',
              backgroundColor: '#42A5F5',
              borderColor: '#1E88E5',
              data: this.dataBar1
          },
          {
              label: 'כמות רכישות',
              backgroundColor: '#9CCC65',
              borderColor: '#7CB342',
              data:this.dataBar2
          }
      ]
  }
  this.dataPie = {
      labels: ['מוצרים שנצפו','מוצרים שנרכשו'],
      datasets: [
          {
              data: [this.dataPie1, this.dataPie2],
              backgroundColor: [
                  "#FF6384",
                  "#36A2EB"
              ],
              hoverBackgroundColor: [
                  "#FF6384",
                  "#36A2EB"
              ]
          }]    
      };
    })  
    })
    
    }
    this.optionsBar = {
      title: {
          display: true,
          text: 'צפיות ורכישות למוצר',
          fontSize: 16
      },
      legend: {
          position: 'bottom'
      }
  };
     this.optionsPie = {
      title: {
          display: true,
          text: 'כל הצפיות והרכישות',
          fontSize: 16
      },
      legend: {
          position: 'bottom'
      }
  }; 
  }

  ngOnInit() {
  }

}
