import { Injectable } from '@angular/core';
import { AppComponent } from './app.component';

@Injectable({
  providedIn: 'root'
})
export class ToggleCartService {

  constructor() { }

  // toggle() {
  //   AppComponent.prototype.toggleCart.call(AppComponent);
  // }
}
