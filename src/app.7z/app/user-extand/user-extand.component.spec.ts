import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserExtandComponent } from './user-extand.component';

describe('UserExtandComponent', () => {
  let component: UserExtandComponent;
  let fixture: ComponentFixture<UserExtandComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserExtandComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserExtandComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
