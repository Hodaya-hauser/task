import { Component, OnInit} from '@angular/core';
import { NavigateServiceService } from '../navigate-service.service';
import { HttpClient} from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { ItemsServiesDTO } from '../shared/classes/ItemsServiesDTO';
import {MenuItem, MessageService} from 'primeng/api';
import {FormControl, Validators, FormGroup, FormBuilder} from '@angular/forms';
import { ItemsServiesService } from '../shared/services/items-servies.service';
import { UsersService } from '../shared/services/users.service';
import { ItemsServies } from '../shared/classes/ItemsServies';
@Component({
  selector: 'app-user-extand',
  templateUrl: './user-extand.component.html',
  styleUrls: ['./user-extand.component.css']
  
})
export class UserExtandComponent implements OnInit {
  email = new FormControl('', [Validators.required, Validators.email]);
  nameer = new FormControl('', [Validators.required,Validators.maxLength(50)]);
  buy: ItemsServies[];
itemservies:ItemsServies[];
  getErrorMessage() {
    if (this.submitted) {
         return this.email.hasError('required') ?'שדה חובה':
        this.email.hasError('email') ? 'מייל לא חוקי':
            '';
    }else{
      return this.email.hasError('email') ? 'מייל לא חוקי':
      '';
    }
 
  }
  getErrorMessagename() {
    if (this.submitted) {
      return this.nameer.hasError('required') ? 'שדה חובה':
    this.nameer.hasError('maxLenght') ? 'שם לא חוקי':
            '';
    }
    
  }
  itemServise:ItemsServies;
  iditems:number[]=[];
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  submitted:boolean=false;
  items: MenuItem[];
  public show: boolean = false;
  public show1: boolean = false;
  public showErrorMass:boolean=false;
  xxx: number = 0;
  mail: string = "";
  name: string = "";
  userId:number;
  id:number;
  item:ItemsServiesDTO;
  complete:boolean=false;
  state:string="edit";
  sug:number;
  ctgr:number;
  constructor(private service: NavigateServiceService,
    private http:HttpClient,
    private active:ActivatedRoute,
    private r:Router,
    private _formBuilder: FormBuilder,
    private ItemsServiesService:ItemsServiesService,
    private UsersService:UsersService,
    private messageService:MessageService) 
  { 
  }
  ngOnInit() {
    this.id= this.active.snapshot.params['id'];
    this.sug = this.active.snapshot.params['sug'];
    this.ctgr = this.active.snapshot.params['ctgr'];
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: []
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
      this.items = [
        {label: 'סיכום'},
        {label: 'התחברות'},
        {label: 'הצגת קופון'}
    ];
    this.buy=JSON.parse(localStorage.getItem("buy"));
       this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
      this.itemservies=<ItemsServies[]>x;
    this.cheack_buy();
    console.log(this.itemservies)
    if(this.buy.length==0)
    {
     this.messageService.add({severity:'warn', summary:'אין מוצרים לרכישה', detail:''});
    }
  
this.buy.forEach(element=>{
  if(this.itemservies)
 {
 if(!this.itemservies.find(data=>data.ISId==element.ISId))
 {
  this.buy.splice(this.buy.findIndex(x=>x.ISId==element.ISId), 1);
    localStorage.setItem("buy",JSON.stringify(this.buy));
 }}
 if(!this.buy)
 {
  this.messageService.add({severity:'warn', summary:'אין מוצרים לרכישה', detail:''});
 }
})})
  }
  cheack_buy(){
    
      this.buy.forEach(element=>{
     if(this.itemservies.find(data=>data.ISId==element.ISId)==null)
     {
      this.buy.splice(this.buy.findIndex(x=>x.ISId==element.ISId), 1);
        localStorage.setItem("buy",JSON.stringify(this.buy));
     }

    }) 
  }
  // selectionChange(e)
  // {
  // if(e.selectedIndex==2)
  // {
  //   this.showcoupon();
  // }
  // if(e.selectedIndex==0)
  // { 
  //   this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
  //   this.itemservies=<ItemsServies[]>x;
  //   this.cheack_buy();
    
  //   if(this.buy.length!=0)
  //   {if(this.id==0)
  //   {debugger;
  //     this.service.NextPAge("allcoupon")
  //   }
  //   else{
  //     if(this.ctgr)
  //     {
  //       this.service.NextPAgeWith3Param("buysum",this.id,this.sug,this.ctgr);
  //     }
  //     else{
  //       this.service.NextPAgeWith2Param("buysum",this.id,this.sug);
  //     }
  //   }}})
  // }
  // }
  selectionChange(e)
  {
  if(e.selectedIndex==2)
  {document.getElementById("buttonAdd").click();
  }
  if(e.selectedIndex==0)
  {
    this.check_buy();
    if(this.buy.length!=0)
   { 
     if(this.id!=0)
    {
      if(this.ctgr)
      {
      this.service.NextPAgeWith3Param("buysum",this.id,this.sug,this.ctgr)
      }
      else{  
      this.service.NextPAgeWith2Param("buysum",this.id,this.sug)   
      }
    }
    else{
      this.service.NextPAge("allcoupon")
    }
  }

  }
  }
  check_buy(){
    this.ItemsServiesService.GetISByStatus(1).subscribe(x=>{
      this.itemservies=<ItemsServies[]>x;
      this.buy.forEach(element=>{
     if(this.itemservies.find(data=>data.ISId==element.ISId)==null)
     {
      this.buy.splice(this.buy.findIndex(x=>x.ISId==element.ISId), 1);
        localStorage.setItem("buy",JSON.stringify(this.buy));
     }

    })
    })
    console.log(this.buy)
  }
  showcoupon() {
    if(this.buy.length==0)
 {
  this.messageService.add({severity:'warn', summary:'אין מוצרים לרכישה', detail:''});
 }
 else{
 if (this.nameer.invalid||this.email.invalid) {
  
   this.submitted=true;
   this.showErrorMass=true;
   this.show=false;
   this.show1=false;
 }  else{
   this.showErrorMass=false;
    
    this.UsersService.Get( this.mail , this.name).subscribe(res => {
      this.userId = <number>res;
      
      if (this.userId != 0) 
      {
        
        let buy:ItemsServiesDTO[]=JSON.parse(localStorage.getItem("buy"));
         console.log(JSON.stringify(this.iditems));
              const frmData = new FormData();
            frmData.append("ItemServies",localStorage.getItem("buy"));
            this.UsersService.Put(this.userId,frmData).
            subscribe ( x=> {
              let existitm:ItemsServiesDTO[];
              existitm=<ItemsServiesDTO[]>x;
              this.show = false;
              // if(x==true)
              if(existitm.length==0)
              { 
                  this.complete=true;
                  if(this.id==0)
                  {
                  localStorage.removeItem("cart")
                  }
                    this.service.NextPAgeWithParam("buy-show-coupon",this.userId);
              
              }
              else
              {
              //   if(existitm.length==1)
              // { 
                // if(this.id!=0)
                // this.show1 = true;
                // if(this.id==0)
            // { 
              // localStorage.setItem("cart",JSON.stringify(existitm));
              //   this.service.NextPAge("existitms")
              // }
              // }
              // else{
                if(this.id==0)
               { localStorage.setItem("cart",JSON.stringify(existitm));}
                localStorage.setItem("buy",JSON.stringify(existitm));
                this.service.NextPAge("existitms")
              // }
            }
            });
      }
         else 
        {
         this.show = true;
         this.show1 = false;
        }
    });
  }
  }
}}